<html>
<head>
    <link href="../../css/prism.css" rel="stylesheet">
    <link href="../../css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
</head>
   

<?php

	include('dbconn.php');

if($_REQUEST)
{
	$id 	= $_REQUEST['parent_id'];
	$query = "SELECT * FROM subcategories WHERE categoryid = ".$id;
	$results = mysqli_query($conn, $query);
	
	
	echo"
	<select name='item_subcategoryid'  id='sub_category_id'>
	<option value='' disabled selected>Choose your option</option>";
	while ($row2 = mysqli_fetch_assoc(@$results)){
		echo"<option value='$row2[id]'>".$row2['subcategoryname']."</option>";
	}
	echo"</select><label>Sub Category</label>";
	


}
?>
<!--  Scripts-->
    
    <script>if (!window.jQuery) { document.write('<script src="../../bin/jquery-2.1.1.min.js"><\/script>'); }
    </script>
    <script src="../../js/jquery.timeago.min.js"></script>
    <script src="../../js/prism.js"></script>
    <script src="../../jade/lunr.min.js"></script>
    <script src="../../jade/search.js"></script>
    <script src="../../bin/materialize.js"></script>
    <script src="../../js/init.js"></script>
</html>