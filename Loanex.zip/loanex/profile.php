<?php

	include('dbconn.php');
  session_start();

  if(!isset($_SESSION['username'])){
    echo "<script>alert('You must be logged in to enter this page!'); window.location = 'index.php';</script>";
  }


  if(isset($_POST['btnupdate'])){
    $update_fname = addslashes($_POST['fname']);
    $update_lname = addslashes($_POST['lname']);
    $update_email = addslashes($_POST['email']);
    $update_address = addslashes($_POST['address']);
    $update_mobile = addslashes($_POST['mobile']);
    $update_zip = addslashes($_POST['zip']);
    $update_gender = addslashes($_POST['gender']);

    if((empty($update_fname)) || (empty($update_fname)) || (empty($update_fname)) || (empty($update_fname)) || (empty($update_fname)) || (empty($update_fname))){
      echo "<script>alert('Some fields are empty!');</script>";
    }else{

    $update_profile = "UPDATE users SET fname = '$update_fname', lname = '$update_lname', email = '$update_email', default_address = '$update_address', mobile = '$update_mobile', zip = '$update_zip', gender = '$update_gender' WHERE username = '$_SESSION[username]'";
    $result_update_profile = mysqli_query($conn, $update_profile);
    if ($result_update_profile){
      echo "<script>alert('Profile successfully updated!');</script>";
    }else{
      echo "<script>alert('Updating profile failed');</script>";
    }
  }
  }

  if(isset($_POST['btnupdatepass'])){
    $update_pass = md5(addslashes($_POST['password']));
    $update_newpass = md5(addslashes($_POST['newpass']));
    $update_renewpass = md5(addslashes($_POST['renewpass']));

    if((empty($update_pass)) || (empty($update_newpass)) || (empty($update_renewpass))){
      echo "<script>alert('Some fields are empty!');</script>";
    }else{
      if ($update_newpass != $update_renewpass){
        echo "<script>alert('New Password not match!');</script>";
      }else{
        $check_curr = "SELECT * FROM users WHERE username = '$_SESSION[username]' AND password = '$update_pass'";
        $result_check_curr = mysqli_query($conn, $check_curr);
        if ($result_check_curr){
          $counter_check_curr = mysqli_num_rows($result_check_curr);
          if ($counter_check_curr>0){
            $update_password = "UPDATE users SET password = '$update_newpass' WHERE username = '$_SESSION[username]' AND password = '$update_pass'";
            $result_update_password = mysqli_query($conn, $update_password);
            if ($result_update_password){
              echo "<script>alert('Successfully updating your password!');</script>";
            }else{
              echo "<script>alert('Failed to update your password');</script>";
            }
          }else{
            echo "<script>alert('Current Password Mismatch!');</script>";
          }
        }
      }
    }
  }

  if(isset($_POST['btnupdatephoto'])){
  $target_dir = "images/profile/";
  if(!is_dir($target_dir)) {
    mkdir($target_dir);
    }
  $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
  $uploadOk = 1;
  $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
  // Check if image file is a actual image or fake image
  if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
  }
  // Check if file already exists
  if (file_exists($target_file)) {
    echo "<script type='text/javascript'>
              alert('Sorry file already exist! Try to rename the file and try again')
              window.location = 'profile.php'
              </script>";
    $uploadOk = 0;
  }
  // Check file size
  if ($_FILES["fileToUpload"]["size"] > 2000000) {
    echo"<script type='text/javascript'>
              alert('File too large!')
              window.location = 'profile.php'
              </script>";
    $uploadOk = 0;
  }
  // Allow certain file formats
  if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
  && $imageFileType != "gif" ) {
    echo"<script type='text/javascript'>
              alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed!')
              window.location = 'profile.php'
              </script>";
    $uploadOk = 0;
  }
  // Check if $uploadOk is set to 0 by an error
  if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
  // if everything is ok, try to upload file
  } else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
      //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
      $nameandir = $target_dir.basename( $_FILES["fileToUpload"]["name"]);
      $update_photo_query = mysqli_query($conn ,"UPDATE users SET imglink = '$nameandir' WHERE username = '$_SESSION[username]'");
      if($update_photo_query){
        echo"<script type='text/javascript'>
              alert('Profile Photo Updated!')
              window.location = 'profile.php'
              </script>";
      }else{
        echo"<script type='text/javascript'>
              alert('Profile Photo Update Unsucessful!')
              window.location = 'profile.php'
              </script>";
      }
    } else {
      echo "<script type='text/javascript'>
              alert('Error! Photo can't be uploaded!')
              window.location = 'profile.php'
              </script>";
    }
  }
  
  }

?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content=" Description here ">
    <title></title>
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
    <!--  Android 5 Chrome Color-->
    <meta name="theme-color" content="#009688">
    <!-- CSS-->
    <link href="css/prism.css" rel="stylesheet">
    <link href="css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   	<script src="js/sidemenu.js"></script>

<style>
  body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }

  nav ul li a:hover, nav ul li.active {
    background-color: #00695c;
  }
      
</style>
</head>
<body>

   <header>
      <div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only"><i class="material-icons" style="padding-top: 8px">menu</i></a></div>
      <ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="#" class="brand-logo">
            <img id="front-page-logo" src="images/logo.png"></a></li>
        <li class='bold'><a href='index.php' class='waves-effect waves-teal'>Home</a></li>
        <?php
          if(!isset($_SESSION['username'])){
            echo "<li class='bold'><a href='#login_modal' class='modal-trigger waves-effect waves-teal'>Login</a></li>";
          }else{
            echo "<li class='bold'><a class='waves-effect waves-light' href='profile.php'>My Profile</a></li>";
            echo "<li class='bold'><a class='waves-effect waves-light' href='orders.php'>My Orders</a></li>";
            $get_cart = "SELECT * FROM cart WHERE username = '$_SESSION[username]'";
            $result_get_cart = mysqli_query($conn, $get_cart);
            if ($result_get_cart){
              $counter_get_cart = mysqli_num_rows($result_get_cart);
                if ($counter_get_cart>0){
                  echo "<li class='bold'><a href='cart.php' class='waves-effect waves-teal'>Cart [ ".$counter_get_cart." ]</a></li>";
                }else{
                  echo "<li class='bold'><a class='waves-effect waves-light' href='cart.php'>Cart</a></li>";
                }
              }
            
            echo "<li class='bold'><a href='logout.php' class='waves-effect waves-teal'>Logout</a></li>";
          }
        ?>
    <li>&nbsp; &nbsp;Categories</li>
		<li class="no-padding">
        <ul class="collapsible collapsible-accordion">
        <?php

        	$load_maincategory_query = "SELECT * FROM categories";
        	$result_maincategory = mysqli_query($conn, $load_maincategory_query);
        	if ($result_maincategory){
        		$counter_maincategory = mysqli_num_rows($result_maincategory);
        			if ($counter_maincategory>0){
        				while($row = mysqli_fetch_assoc($result_maincategory)){
        				$maincategory_id = $row['id'];
        				$maincategory_name = $row['categoryname'];
        					echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>".$maincategory_name."</a>";
        					$load_subcategory_query = "SELECT * FROM subcategories WHERE categoryid = '$maincategory_id'";
        					$result_subcategory = mysqli_query($conn, $load_subcategory_query);
        					if ($result_subcategory){
        						$counter_subcategory = mysqli_num_rows($result_subcategory);
        						if ($counter_subcategory>0){
		        					while($row2 = mysqli_fetch_assoc($result_subcategory)){
		        					$subcategory_maincategoryid = $row2['categoryid'];
		        					$subcategory_name = $row2['subcategoryname'];
                      $subcategory_id = $row2['id'];
                      $get_items_on_this_category = "SELECT * FROM items WHERE categoryid = $maincategory_id AND subcategoryid = $subcategory_id";
                      $result_items_on_this_category = mysqli_query($conn, $get_items_on_this_category);
                      if ($result_items_on_this_category){
                        $counter_items_on_this_category = mysqli_num_rows($result_items_on_this_category);
		        						echo"        	              
		        							<div class='collapsible-body'>
								                <ul>
													<li><a href='items.php?ctgid=".$maincategory_id."&sctgid=".$subcategory_id."'>".$subcategory_name." (".$counter_items_on_this_category.")</a></li>
								                </ul>
							                </div>";
                      }
		        					}
        						}else{
        							echo"        	              
		        							<div class='collapsible-body'>
								                <ul>
													<li><a href='#'>Failed to load</a></li>
								                </ul>
							                </div>";
        						}
        					}
        				}
        			}else{
        				echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>Failed to load</a>";
        			}
        	}



        ?>
        </li>
            
      </ul>
	  </li>
    </header>

  <nav>
    <div class="nav-wrapper teal">
      <a href="#" class="brand-logo"><img id="front-page-logo" src="images/logo.png"></a>
      <ul class="right hide-on-med-and-down">
      <?php
      if(isset($_SESSION['username'])){
        $get_cart = "SELECT * FROM cart WHERE username = '$_SESSION[username]'";
        $result_get_cart = mysqli_query($conn, $get_cart);
        if ($result_get_cart){
          $counter_get_cart = mysqli_num_rows($result_get_cart);
            if ($counter_get_cart>0){
              echo "<li><a class='waves-effect waves-light' href='cart.php'>Cart<i class='left material-icons'>shopping_cart</i><span class='badge white-text'>[ ".$counter_get_cart." ]</span></a></li>";
            }else{
              echo "<li><a class='waves-effect waves-light' href='cart.php'>Cart<i class='left material-icons'>shopping_cart</i></a></li>";
            }
          }
        echo"<li><a class='waves-effect waves-light' href='logout.php'>Logout<i class='left material-icons'>send</i></a></li>";
      }else{
        echo"<li><a class='modal-trigger waves-effect waves-light' href='#login_modal'>Login<i class='left material-icons'>send</i></a></li>";
      }

      ?>
      </ul>
    </div>
  </nav>
  
              <?php
              $userdata = "SELECT * FROM users WHERE username = '$_SESSION[username]'";
              $result_userdata = mysqli_query($conn, $userdata);
              if ($result_userdata){
                $counter_userdata = mysqli_num_rows($result_userdata);
                if ($counter_userdata>0){
                  while($row3 = mysqli_fetch_assoc($result_userdata)){
                    $fullname = $row3['fname'] . " " . $row3['lname'];
                    $fname = $row3['fname'];
                    $lname = $row3['lname'];
                    $address = $row3['default_address'];
                    $email = $row3['email'];
                    $mobile = $row3['mobile'];
                    $zip = $row3['zip'];
                    $gender = $row3['gender'];
                    $imglink = $row3['imglink'];
                  }
                }
              }
              ?>

  <main>
  <div class="section">
    <div class="row">
	     <div class="container">
          <div class='col s12'>
            <div class="row">
              <div class='col s4'>
                <img class='responsive-img' src='<?php echo $imglink; ?>'>
              </div>
              <div class='col s8'>
                <h4><?php echo $fullname; ?></h4>
                <br>
                <a href='#edit_profile' class="modal-trigger waves-effect waves-light btn"><i class="material-icons left">mode_edit</i>Profile</a>
                <a href='#edit_password' class="modal-trigger waves-effect waves-light btn"><i class="material-icons left">mode_edit</i>Password</a>
              </div>
            </div>
            <div class='card'>
              <div class='card-content'>
                <div class="row">
                <div class='container'>
                <h6><b>Profile Details:</b></h6>
                <br>
                  <div class="col s12">
                    <h6>Address:</h6>
                    <h6><b><?php echo $address; ?></b></h6>
                    <br>
                    <h6>Email:</h6>
                    <h6><b><?php echo $email; ?></b></h6>
                    <br>
                    <h6>Mobile #:</h6>
                    <h6><b><?php echo $mobile; ?></b></h6>
                    <br>
                    <h6>Zip Code:</h6>
                    <h6><b><?php echo $zip; ?></b></h6>
                    <br>
                    <h6>Gender:</h6>
                    <h6><b><?php if($gender == 1){ echo "Male"; } elseif ($gender == 0)  { echo "Female"; } else { echo "Unidentified"; } ?></b></h6>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
				</div>
	   </div>
	</div>
  </main>
  
  <footer class="page-footer teal">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2016 Lozodo lol
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
    </footer>

  <div id="edit_profile" class="modal">
    <div class="modal-content">
      <h5>Edit Profile</h5>
        <form method='post' action='#' class='col s12'>
          <div class="row">
            <div class="input-field col s12">
              <input id="fname" name='fname' type="text" class="validate" value="<?php echo $fname; ?>">
              <label for="fname">First Name</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="lname" name='lname' type="text" class="validate" value="<?php echo $lname; ?>">
              <label for="lname">Last Name</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="email" name='email' type="email" class="validate" value="<?php echo $email; ?>">
              <label for="email">Email</label>
            </div>
          </div>
          <div class="row">
              <div class="row">
                <div class="input-field col s12">
                  <textarea id="address" name='address' class="materialize-textarea"><?php echo $address; ?></textarea>
                  <label for="address">Address</label>
                </div>
              </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="mobile" name='mobile' type="number" class="validate" value="<?php echo $mobile; ?>">
              <label for="mobile">Mobile #</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="zip" name='zip' type="number" class="validate" value="<?php echo $zip; ?>">
              <label for="zip">Zip Code</label>
            </div>
          </div>
          <div class='row'>
            <div class='col s6'>
            Gender:
            <?php
              if($gender == 1){
                echo "
                  <p>
                    <input name='gender' type='radio' id='g-male' value='1' checked/>
                    <label for='g-male'>Male</label>
                  </p>
                  <p>
                    <input name='gender' type='radio' id='g-female' value='0'/>
                    <label for='g-female'>Female</label>
                  </p>

                ";
              }else{
                echo "
                  <p>
                    <input name='gender' type='radio' id='g-male' value='1'/>
                    <label for='g-male'>Male</label>
                  </p>
                  <p>
                    <input name='gender' type='radio' id='g-female' value='0' checked/>
                    <label for='g-female'>Female</label>
                  </p>

                ";
              }
            ?>
            </div>
          </div>
          <div class="row">
            <div class="col s12 center">
              <button name='btnupdate' class="waves-effect waves-light btn">Update</button>
              <a href='#update_photo' class="modal-trigger waves-effect waves-light btn">Upload Photo</a>
            </div>
          </div>
        </form>
    </div>
  </div>

  <div id="edit_password" class="modal">
    <div class="modal-content">
      <h5>Edit Password</h5>
        <form method='post' action='#' class='col s12'>
          <div class="row">
            <div class="input-field col s12">
              <input id="password" name='password' type="password" class="validate" required>
              <label for="password">Current Password</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="newpass" name='newpass' type="password" class="validate" required>
              <label for="newpass">New Password</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="renewpass" name='renewpass' type="password" class="validate" required>
              <label for="renewpass">Retype New Password</label>
            </div>
          </div>
          <div class="row">
            <div class="col s12 center">
              <button name='btnupdatepass' class="waves-effect waves-light btn">Update</a>
            </div>
          </div>
        </form>
    </div>
  </div>

    <div id="update_photo" class="modal">
    <div class="modal-content">
      <h5>Edit Profile Photo</h5>
      <br>
          <form ENCTYPE='multipart/form-data' class="col s12" method="post" action="#">
            <input type='hidden' name='photo_itemid' id='photo_itemid'>
            <div class="file-field input-field">
              <div class="btn">
                <span>Image</span>
                <input type="file" name="fileToUpload" id="fileToUpload" accept="image/x-png, image/jpeg" required> 
              </div>
              <div class="file-path-wrapper">
                <input class="file-path validate" type="text">
              </div>
            </div>
            <div class='col s12 center'>
            <button name='btnupdatephoto' class="waves-effect waves-light btn">Upload</button>
            </div>
          </form>
    </div>
  </div>
	
	<!--  Scripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.js"><\/script>'); }
    </script>
    <script src="js/jquery.timeago.min.js"></script>
    <script src="js/prism.js"></script>
    <script src="jade/lunr.min.js"></script>
    <script src="jade/search.js"></script>
    <script src="bin/materialize.js"></script>
    <script src="js/init.js"></script>	

	
</body>
</html>