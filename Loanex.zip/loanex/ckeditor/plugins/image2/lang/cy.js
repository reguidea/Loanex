/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'cy', {
	alt: 'Testun Amgen',
	btnUpload: 'Anfon i\'r Gweinydd',
	captioned: 'Delwedd â phennawd',
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Gwyb Delwedd',
	lockRatio: 'Cloi Cymhareb',
	menu: 'Priodweddau Delwedd',
	pathName: 'delwedd',
	pathNameCaption: 'pennawd',
	resetSize: 'Ailosod Maint',
	resizer: 'Clicio a llusgo i ail-meintio',
	title: 'Priodweddau Delwedd',
	uploadTab: 'Lanlwytho',
	urlMissing: 'URL gwreiddiol y ddelwedd ar goll.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
