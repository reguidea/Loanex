#### Features

- **Breadcrumb** - Breadcrumb no longer receives vertical spacing by default. This may often cause vertical alignment issues when displayed next to other `inline-block` content.

### Version 2.0.0 - June 30, 2015

- **Breadcrumb** - Fixed breadcrumb `em` rounding, adjusted distance in default theme

### UI Changes

- **Breadcrumb** - Breadcrumb icon now has exact px value to alleviate vertical align issues

### Version 0.1.0 - Sep 25, 2013