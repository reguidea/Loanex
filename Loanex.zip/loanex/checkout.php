<?php

	include('dbconn.php');
  session_start();

  if(isset($_POST['loginbtn'])){
    $username = addslashes($_POST['login_username']);
    $password = addslashes(md5($_POST['login_password']));

    $login = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result_login = mysqli_query($conn, $login);
    if($result_login){
      $counter_login = mysqli_num_rows($result_login);
      if ($counter_login>0){
        $_SESSION['username'] = $username;
      }else{
        echo "<script>alert('Username and Password is incorrect');</script>";
      }
    }
  }

  if(isset($_POST['registersubmit'])){
  
    $reg_username = addslashes($_POST['reg_username']);
    $reg_fname = addslashes($_POST['reg_fname']);
    $reg_lname = addslashes($_POST['reg_lname']);
    $reg_password = addslashes(md5($_POST['reg_password']));
    $reg_repassword = addslashes(md5($_POST['reg_repassword']));
    $reg_gender = addslashes($_POST['reg_gender']);
    $reg_email = addslashes($_POST['reg_email']);
    $username_unique_checker_query = mysqli_query($conn ,"SELECT * FROM users WHERE username = '$reg_username'");
    $username_unique_checker = mysqli_num_rows($username_unique_checker_query);
    $email_unique_checker_query = mysqli_query($conn ,"SELECT * FROM users WHERE email = '$reg_email'");
    $email_unique_checker = mysqli_num_rows($email_unique_checker_query);
    
    if ((empty($reg_username))){
      echo"
          <script type='text/javascript'>
          alert('Username must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if ((empty($reg_fname))){
      echo"
          <script type='text/javascript'>
          alert('First Name must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_lname))){
      echo"
          <script type='text/javascript'>
          alert('Last Name must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_password))){
      echo"
          <script type='text/javascript'>
          alert('Password must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_repassword))){
      echo"
          <script type='text/javascript'>
          alert('Re-password must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_email))){
      echo"
          <script type='text/javascript'>
          alert('Email must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if($reg_password != $reg_repassword){
        echo"
          <script type='text/javascript'>
          alert('Password not match!')
          window.location = 'index.php' 
          </script>";
      }else if (!filter_var($reg_email, FILTER_VALIDATE_EMAIL)){
        echo"
          <script type='text/javascript'>
          alert('Invalid Email Format')
          window.location = 'index.php' 
          </script>";
      }else if($username_unique_checker != 0){
        echo"
          <script type='text/javascript'>
          alert('Username already exist!')
          window.location = 'index.php' 
          </script>";
      }else if($email_unique_checker != 0){
        echo"
          <script type='text/javascript'>
          alert('Email already exist!')
          window.location = 'index.php' 
          </script>";
      }else{
        $reg_query = "INSERT INTO users (fname, lname, email, gender, username, password) VALUES ('$reg_fname', '$reg_lname', '$reg_email', '$reg_gender', '$reg_username', '$reg_password')";
        $check = mysqli_query($conn ,$reg_query);
        if (!$check){
          echo "
          <script type='text/javascript'>
          alert('Register failed!')
          </script>";
        }else{
          echo"
            <script type='text/javascript'>
            window.location = 'index.php' 
            alert('Successfully registed!')
            
            </script>
            ";
          
        }
      }
    }

  if(isset($_POST['checkout_continue'])){
    $radiobutton = $_POST['group1'];
    if ($radiobutton == "default"){
        $address = addslashes($_POST['checkout_address']);
        setcookie("lazada_address", $address, time() + (86400 * 30), "/"); 
        $mobile = addslashes($_POST['checkout_mobilenumber']);
        if(!empty($mobile)){
        setcookie("lazada_mobile", $mobile, time() + (86400 * 30), "/");
        }
        //$checkout_zip = $_POST['checkout_zip'];
        $fullname = addslashes($_POST['checkout_fullname']);
        setcookie("lazada_fullname", $fullname, time() + (86400 * 30), "/"); 
        $cart_total = $_POST['cart_total'];
        header("Location: checkout.php?step=2");
        //echo $checkout_fullname;
    }else if($radiobutton = "new"){
      $fullname = addslashes($_POST['fullname']);
      
      $address = addslashes($_POST['address']);
      
      $mobile = addslashes($_POST['mobile']);
      
      $cart_total = $_POST['cart_total'];
      if (empty($fullname)){
        echo "<script>alert('Name must have a value!');</script>";
      }else if(empty($address)){
        echo "<script>alert('Address must have a value!');</script>";
      } else {
        setcookie("lazada_address", $address, time() + (86400 * 30), "/"); 
        setcookie("lazada_fullname", $fullname, time() + (86400 * 30), "/"); 
        setcookie("lazada_mobile", $mobile, time() + (86400 * 30), "/"); 
        header("Location: checkout.php?step=2");
      }
    }
    //header("Location: checkout.php?step=2");
  }

$voucher_status = false;
  if (isset($_POST['applyvoucher'])){
    $current_date = date("Y-m-d");
    $voucher = addslashes($_POST['voucher']);
    $deduct = 0;
    $check_voucher = "SELECT * FROM coupons WHERE code = '$voucher'";
    $result_check_voucher = mysqli_query($conn, $check_voucher);
    if ($result_check_voucher){
      $counter_check_voucher = mysqli_num_rows($result_check_voucher);
      if ($counter_check_voucher>0){
        while($row8 = mysqli_fetch_assoc($result_check_voucher)){
          $pieces = $row8['pieces'];
          $foruser = $row8['user'];
          $have_timelimit = $row8['have_timelimit'];
          $canbeusedbefore = $row8['canbeusedbefore'];
          $deduction = $row8['deduction'];
          $minimum = $row8['minimum'];
        }

          if ($have_timelimit == 1){
            if ($canbeusedbefore > $current_date){
              if(($pieces > 0) || ($pieces == -1)){
                if(($foruser == 'all') || ($foruser == $_SESSION['username'])){
                  if ($cart_total >= $minimum){
                  $deduct = $deduction;
                  $voucher_status = true;
                  setcookie("lazada_couponcode", $voucher, time() + (86400 * 30), "/"); 
                  }else{
                    echo "<script>alert('Your cart must have a total or greater than [₱ ".$minimum."]'); window.location = 'checkout.php?step=2';</script>";
                  }
                }else{
                  echo "<script>alert('This voucher is exclusive for specific users.')</script>";
                }
              }else{
                echo "<script>alert('Coupon out of stock')</script>";
              }
            }else{
              echo "<script>alert('Coupon date passed')</script>";
            }
            }else{
              if(($pieces > 0) || ($pieces == -1)){
                if(($foruser == 'all') || ($foruser == $_SESSION['username'])){
                  if ($cart_total >= $minimum){
                  $deduct = $deduction;
                  $voucher_status = true;
                  setcookie("lazada_couponcode", $voucher, time() + (86400 * 30), "/");
                  }else{
                    echo "<script>alert('Your cart must have a total or greater than [₱ ".$minimum."]'); window.location = 'checkout.php?step=2';</script>";
                  }
                }else{
                  echo "<script>alert('This voucher is exclusive for specific users.')</script>";
                }
              }else{
                echo "<script>alert('Coupon out of stock')</script>";
              }
        }
      }else{
        echo "<script>alert('Voucher Invalid')</script>";
      }
    }
  }

  if(isset($_POST['billing_btn'])){
    $radiobutton2 = $_POST['group2'];
    function randomString($length = 15) {
      $str = "";
      $characters = array_merge(range('A','Z'), range('0','9'));
      $max = count($characters) - 1;
      for ($i = 0; $i < $length; $i++) {
        $rand = mt_rand(0, $max);
        $str .= $characters[$rand];
      }
      return $str;
    }

    $packageid = randomString(20);


    $packageid_unique = "SELECT * FROM checkout_data WHERE packageid = '$packageid'";
    $result_packageid_unique = mysqli_query($conn, $packageid_unique);
    if($result_packageid_unique){
      $counter_packageid_unique = mysqli_num_rows($result_packageid_unique);
        if($counter_packageid_unique>0){
          $packageid = randomString(20);
        }
    }


    if ($radiobutton2 == "cod"){
                          $fail = false;
                          $cart_total2 = 0;
                          $get_cart_data2 = "SELECT * FROM cart WHERE username='".$_SESSION['username']."'";
                          $result_get_cart_data2 = mysqli_query($conn, $get_cart_data2);
                          if ($result_get_cart_data2){
                            $counter_get_cart_data2 = mysqli_num_rows($result_get_cart_data2);
                            if ($counter_get_cart_data2>0){
                              while($row6 = mysqli_fetch_assoc($result_get_cart_data2)){
                                $cart_itemid2 = $row6['itemid'];
                                $cart_qty2 = $row6['qty'];
                                $get_item_data2 = "SELECT * FROM items WHERE id = '$cart_itemid2'";
                                $result_get_item_data2 = mysqli_query($conn, $get_item_data2);
                                if ($result_get_item_data2){
                                  $counter_get_item_data2 = mysqli_num_rows($result_get_item_data2);
                                  if ($counter_get_item_data2>0){
                                    while($row7 = mysqli_fetch_assoc($result_get_item_data2)){
                                      $cart_itemname2 = $row7['name'];
                                      $cart_price2 = $row7['price'];
                                      $cart_discount2 = $row7['discount'];
                                      $stocks = $row7['qty'];
                                      if($stocks>=$cart_qty2){
                                        if ($fail != true){
                                          if ($cart_discount2>0){
                                            $cart_price2 = Round((($cart_price2 - ($cart_price2 * ($cart_discount2/100))) * $cart_qty2), 2);
                                          }else{
                                            $cart_price2 = Round(($cart_price2 * $cart_qty2), 2);
                                          }
                                          if(isset($_COOKIE['lazada_couponcode'])){
                                              $check_voucher1 = "SELECT * FROM coupons WHERE code = '$_COOKIE[lazada_couponcode]'";
                                              $result_check_voucher1 = mysqli_query($conn, $check_voucher1);
                                              if ($result_check_voucher1){
                                                $counter_check_voucher1 = mysqli_num_rows($result_check_voucher1);
                                                if ($counter_check_voucher1>0){
                                                  while($row10 = mysqli_fetch_assoc($result_check_voucher1)){
                                                    $pieces1 = $row10['pieces'];
                                                    $foruser1 = $row10['user'];
                                                    $have_timelimit1 = $row10['have_timelimit'];
                                                    $canbeusedbefore1 = $row10['canbeusedbefore'];
                                                    $deduction1 = $row10['deduction'];
                                                  }
                                                  $minus = $deduction1/$counter_get_cart_data2;
                                                  $cart_price2 = $cart_price2 - Round($minus, 2);
                                                }
                                              }
                                            }
                                          }
                                          $cart_total2 = $cart_total2 + $cart_price2;
                                          $update_stocks = "UPDATE items SET qty = qty - '$cart_qty2' WHERE id = '$cart_itemid2'";
                                          $result_update_stocks = mysqli_query($conn, $update_stocks);
                                          $insert_checkout_package = "INSERT INTO checkout_package (packageid ,itemid, qty, price, username) VALUES ('$packageid', '$cart_itemid2', '$cart_qty2', '$cart_price2', '$_SESSION[username]')";
                                          $result_insert_checkout_package = mysqli_query($conn, $insert_checkout_package);
                                          if ($result_insert_checkout_package){
                                            
                                              $done = true;
                                            
                                          }else{
                                            echo "failed";
                                          }
                                      }else{
                                        if($stocks == 0){
                                        $update_cartqty = "DELETE FROM cart WHERE username = '$_SESSION[username]' AND itemid = '$cart_itemid2'";
                                        }else{
                                        $update_cartqty = "UPDATE cart SET qty = '$stocks' WHERE username = '$_SESSION[username]' AND itemid = '$cart_itemid2'";
                                        }
                                        $result_update_cartqty = mysqli_query($conn, $update_cartqty);
                                        if ($result_update_cartqty){
                                          echo "<script>alert('Your Item: [".$cart_itemname2."] quantity in your cart has been adjusted / removed due to insufficient stocks')</script>";
                                        }
                                        $done = false;
                                            unset($_COOKIE['lazada_fullname']);
                                            unset($_COOKIE['lazada_address']);
                                            unset($_COOKIE['lazada_mobile']);
                                            setcookie('lazada_fullname', null, -1, '/');
                                            setcookie('lazada_address', null, -1, '/');
                                            setcookie('lazada_mobile', null, -1, '/');
                                        $fail = true;
                                      }
                                    }
                                  }
                                }
                              }
                            }
                            if ($done == true){
                                        if (isset($_COOKIE['lazada_couponcode'])){
                                          $insert_coupon_code = $_COOKIE['lazada_couponcode'];
                                        $insert_checkout_data = "INSERT INTO checkout_data (username, packageid, fullname, address, mobile, modeofpayment, coupon) VALUES ('$_SESSION[username]', '$packageid', '$_COOKIE[lazada_fullname]', '$_COOKIE[lazada_address]', '$_COOKIE[lazada_mobile]', '$radiobutton2', '$insert_coupon_code')";
                                              $check_voucher = "SELECT * FROM coupons WHERE code = '$_COOKIE[lazada_couponcode]'";
                                              $result_check_voucher = mysqli_query($conn, $check_voucher);
                                              if ($result_check_voucher){
                                                $counter_check_voucher = mysqli_num_rows($result_check_voucher);
                                                if ($counter_check_voucher>0){
                                                  while($row9 = mysqli_fetch_assoc($result_check_voucher)){
                                                    $pieces = $row9['pieces'];
                                                    $foruser = $row9['user'];
                                                    $have_timelimit = $row9['have_timelimit'];
                                                    $canbeusedbefore = $row9['canbeusedbefore'];
                                                    $deduction = $row9['deduction'];
                                                    $minimum = $row9['minimum'];
                                                  }
                                                  if($pieces > 0){
                                                    $deduct_pieces = "UPDATE coupons SET pieces = pieces - 1 WHERE code = '$_COOKIE[lazada_couponcode]'";
                                                    $result_deduct_pieces = mysqli_query($conn, $deduct_pieces);
                                                  }
                                                }
                                              }
                                        }else{
                                        $insert_checkout_data = "INSERT INTO checkout_data (username, packageid, fullname, address, mobile, modeofpayment) VALUES ('$_SESSION[username]', '$packageid', '$_COOKIE[lazada_fullname]', '$_COOKIE[lazada_address]', '$_COOKIE[lazada_mobile]', '$radiobutton2')";
                                        }

                                        $result_insert_checkout_data = mysqli_query($conn, $insert_checkout_data);
                                        if ($result_insert_checkout_data){
                                          $delete_cart_data = "DELETE FROM cart WHERE username = '$_SESSION[username]'";
                                          $result_delete_cart_data = mysqli_query($conn, $delete_cart_data);
                                          if ($result_delete_cart_data){
                                            unset($_COOKIE['lazada_fullname']);
                                            unset($_COOKIE['lazada_address']);
                                            unset($_COOKIE['lazada_mobile']);
                                            setcookie('lazada_fullname', null, -1, '/');
                                            setcookie('lazada_address', null, -1, '/');
                                            setcookie('lazada_mobile', null, -1, '/');
                                            if (isset($_COOKIE['lazada_couponcode'])){
                                            unset($_COOKIE['lazada_couponcode']);
                                            setcookie('lazada_couponcode', null, -1, '/');
                                            }
                                            echo "<script>alert('Order Successfully Placed');window.location.href = 'index.php' </script>";
                                          }
                                        }else{
                                          echo mysqli_error($conn);
                                        }
                            }
                          }
  }
}

?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content=" Description here ">
    <title></title>
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
    <!--  Android 5 Chrome Color-->
    <meta name="theme-color" content="#009688">
    <!-- CSS-->
    <link href="css/prism.css" rel="stylesheet">
    <link href="css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   	<script src="js/sidemenu.js"></script>
    <link href="css/custom/step/step.css" rel="stylesheet">

<style>
  body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }

  nav ul li a:hover, nav ul li.active {
    background-color: #00695c;
  }

      
</style>
</head>
<body>

   <header>
      <div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only"><i class="material-icons" style="padding-top: 8px">menu</i></a></div>
      <ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="#" class="brand-logo">
            <img id="front-page-logo" src="images/logo.png"></a></li>
        <li class='bold'><a href='index.php' class='waves-effect waves-teal'>Home</a></li>
        <?php
          if(!isset($_SESSION['username'])){
            echo "<li class='bold'><a href='#login_modal' class='modal-trigger waves-effect waves-teal'>Login</a></li>";
          }else{
            echo "<li class='bold'><a class='waves-effect waves-light' href='profile.php'>My Profile</a></li>";
            echo "<li class='bold'><a class='waves-effect waves-light' href='orders.php'>My Orders</a></li>";
            $get_cart = "SELECT * FROM cart WHERE username = '$_SESSION[username]'";
            $result_get_cart = mysqli_query($conn, $get_cart);
            if ($result_get_cart){
              $counter_get_cart = mysqli_num_rows($result_get_cart);
                if ($counter_get_cart>0){
                  echo "<li class='bold'><a href='cart.php' class='waves-effect waves-teal'>Cart [ ".$counter_get_cart." ]</a></li>";
                }else{
                  echo "<li class='bold'><a class='waves-effect waves-light' href='cart.php'>Cart</a></li>";
                }
              }
            
            echo "<li class='bold'><a href='logout.php' class='waves-effect waves-teal'>Logout</a></li>";
          }
        ?>
    <li>&nbsp; &nbsp;Categories</li>
		<li class="no-padding">
        <ul class="collapsible collapsible-accordion">
        <?php

        	$load_maincategory_query = "SELECT * FROM categories";
        	$result_maincategory = mysqli_query($conn, $load_maincategory_query);
        	if ($result_maincategory){
        		$counter_maincategory = mysqli_num_rows($result_maincategory);
        			if ($counter_maincategory>0){
        				while($row = mysqli_fetch_assoc($result_maincategory)){
        				$maincategory_id = $row['id'];
        				$maincategory_name = $row['categoryname'];
        					echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>".$maincategory_name."</a>";
        					$load_subcategory_query = "SELECT * FROM subcategories WHERE categoryid = '$maincategory_id'";
        					$result_subcategory = mysqli_query($conn, $load_subcategory_query);
        					if ($result_subcategory){
        						$counter_subcategory = mysqli_num_rows($result_subcategory);
        						if ($counter_subcategory>0){
		        					while($row2 = mysqli_fetch_assoc($result_subcategory)){
		        					$subcategory_maincategoryid = $row2['categoryid'];
		        					$subcategory_name = $row2['subcategoryname'];
                      $subcategory_id = $row2['id'];
                      $get_items_on_this_category = "SELECT * FROM items WHERE categoryid = $maincategory_id AND subcategoryid = $subcategory_id";
                      $result_items_on_this_category = mysqli_query($conn, $get_items_on_this_category);
                      if ($result_items_on_this_category){
                        $counter_items_on_this_category = mysqli_num_rows($result_items_on_this_category);
		        						echo"        	              
		        							<div class='collapsible-body'>
								                <ul>
													<li><a href='items.php?ctgid=".$maincategory_id."&sctgid=".$subcategory_id."'>".$subcategory_name." (".$counter_items_on_this_category.")</a></li>
								                </ul>
							                </div>";
                      }
		        					}
        						}else{
        							echo"        	              
		        							<div class='collapsible-body'>
								                <ul>
													<li><a href='#'>Failed to load</a></li>
								                </ul>
							                </div>";
        						}
        					}
        				}
        			}else{
        				echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>Failed to load</a>";
        			}
        	}



        ?>
        </li>
            
      </ul>
	  </li>
    </header>

  <nav>
    <div class="nav-wrapper teal">
      <a href="#" class="brand-logo"><img id="front-page-logo" src="images/logo.png"></a>
      <ul class="right hide-on-med-and-down">
      <?php
      if(isset($_SESSION['username'])){
        $get_cart = "SELECT * FROM cart WHERE username = '$_SESSION[username]'";
        $result_get_cart = mysqli_query($conn, $get_cart);
        if ($result_get_cart){
          $counter_get_cart = mysqli_num_rows($result_get_cart);
            if ($counter_get_cart>0){
              echo "<li><a class='waves-effect waves-light' href='cart.php'>Cart<i class='left material-icons'>shopping_cart</i><span class='badge white-text'>[ ".$counter_get_cart." ]</span></a></li>";
            }else{
              echo "<li><a class='waves-effect waves-light' href='cart.php'>Cart<i class='left material-icons'>shopping_cart</i></a></li>";
            }
          }
        echo"<li><a class='waves-effect waves-light' href='logout.php'>Logout<i class='left material-icons'>send</i></a></li>";
      }else{
        echo"<li><a class='modal-trigger waves-effect waves-light' href='#login_modal'>Login<i class='left material-icons'>send</i></a></li>";
      }

      ?>
      </ul>
    </div>
  </nav>
  
  <main>
  <div class="section">
    <div class="row">
	     <div class="container">
        <div class="col s12">
          <div class="ui three top attached steps">
          <?php
            if(isset($_REQUEST['step'])){
              $step = $_REQUEST['step'];

              if($step == 1){
                echo"
                  <div class='active step'>
                    <i class='truck icon'></i>
                    <div class='content'>
                      <div class='title'>Shipping</div>
                      <div class='description'>Choose your shipping options</div>
                    </div>
                  </div>
                  <div class='disabled step'>
                    <i class='payment icon'></i>
                    <div class='content'>
                      <div class='title'>Billing</div>
                      <div class='description'>Enter billing information</div>
                    </div>
                  </div>
                  </div>
                  <div class='ui attached segment'>
                    <p>
                    <div class='col s12'>
                      <div class='card-panel'>
                        <h6><b>Select a shipping address</b></h6>
                        <div class='divider'></div>
                        <form method='post' action='#'>
                        <div>
                        <ul class='collapsible' data-collapsible='accordion'>
                          <li>
                          <div id='collapsible-default' class='collapsible-header active'><i class='material-icons'>filter_drama</i>Default Address</div>
                          <div class='collapsible-body'>
                          <p>
                          <input name='group1' type='radio' id='test1' value='default' checked/>
                          <label for='test1'>Set Shipping Address</label>
                          <div class='container'>";
                            if(isset($_SESSION['username'])){
                            $get_user_data = "SELECT * FROM users WHERE username='$_SESSION[username]'";
                            $result_get_user_data = mysqli_query($conn, $get_user_data);
                            if ($result_get_user_data){
                              $counter_get_user_data = mysqli_num_rows($result_get_user_data);
                              if ($counter_get_user_data>0){
                                while($row3 = mysqli_fetch_assoc($result_get_user_data)){
                                  $user_fullname = $row3['fname'] . " " . $row3['lname'];
                                  $user_activeaddress = $row3['default_address'];
                                  $user_mobilenumber = $row3['mobile'];
                                  $user_zip = $row3['zip'];
                                }
                              }
                            }
                            if ($counter_get_user_data>0){
                              echo "
                                        <b>".$user_fullname."</b><br>".$user_activeaddress."<br>Mobile Number: ".$user_mobilenumber."<br>Zip Code: ".$user_zip."
                                      <input type='hidden' value='".$user_fullname."' name='checkout_fullname'>
                                      <input type='hidden' value='".$user_activeaddress."' name='checkout_address'>
                                      <input type='hidden' value='".$user_mobilenumber."' name='checkout_mobilenumber'>
                                      <input type='hidden' value='".$user_zip."' name='checkout_zip'>
                                   ";
                            }
                            }
                echo"     </div>
                          </p></div></li>
                          <li>
                          <div id='collapsible-new' class='collapsible-header'><i class='material-icons'>place</i>Custom Address</div>
                          <div class='collapsible-body'>
                          
                          <p>
                          <input name='group1' type='radio' id='test2' value='new'/>
                          <label for='test2'>Set Shipping Address</label>
                          <div class='container'>
                          <div class='row'>
                              <div class='row'>
                                <div class='input-field col s12'>
                                  <input id='fullname' name='fullname' type='text' class='validate'>
                                  <label for='fullname'>Fullname</label>
                                </div>
                              </div>
                              <div class='row'>
                                <div class='input-field col s12'>
                                  <input id='address' name='address' type='text' class='validate'>
                                  <label for='address'>Full Address</label>
                                </div>
                              </div>
                              <div class='row'>
                                <div class='input-field col s12'>
                                  <input id='mobile' name='mobile' type='number' class='validate'>
                                  <label for='mobile'>Phone Number</label>
                                </div>
                              </div>
                          </div>
                          </div>
                          </p>
                          </div></li>
                          </ul>
                        </div>
                        
                      </div>
                      
                    </div>
                    </p>
                    <div class='col s12'>
                      <div class='card-panel optionB'>
                        <h6><b>Order Summary</b></h6>
                        <div class='divider'></div>
                        <table class='centered responsive-table'>
                          <thead>
                            <tr>
                                <th data-field='name'>Product</th>
                                <th data-field='qty'>Quantity</th>
                                <th data-field='price'>Price</th>
                            </tr>
                          </thead>

                          <tbody>";
                          $cart_total = 0;
                          $get_cart_data = "SELECT * FROM cart WHERE username='".$_SESSION['username']."'";
                          $result_get_cart_data = mysqli_query($conn, $get_cart_data);
                          if ($result_get_cart_data){
                            $counter_get_cart_data = mysqli_num_rows($result_get_cart_data);
                            if ($counter_get_cart_data>0){
                              while($row4 = mysqli_fetch_assoc($result_get_cart_data)){
                                $cart_itemid = $row4['itemid'];
                                $cart_qty = $row4['qty'];
                                $get_item_data = "SELECT * FROM items WHERE id = '$cart_itemid'";
                                $result_get_item_data = mysqli_query($conn, $get_item_data);
                                if ($result_get_item_data){
                                  $counter_get_item_data = mysqli_num_rows($result_get_item_data);
                                  if ($counter_get_item_data>0){
                                    while($row5 = mysqli_fetch_assoc($result_get_item_data)){
                                      $cart_itemname = $row5['name'];
                                      $cart_price = $row5['price'];
                                      $cart_discount = $row5['discount'];
                                      if ($cart_discount>0){
                                        $cart_price = (($cart_price - ($cart_price * ($cart_discount/100))) * $cart_qty);
                                      }else{
                                        $cart_price = $cart_price * $cart_qty;
                                      }
                                      $cart_total = $cart_total + $cart_price;
                                      echo "<tr>";
                                      echo "<td>".$cart_itemname."</td>";
                                      echo "<td>".$cart_qty."</td>";
                                      echo "<td>₱ ".number_format(Round($cart_price, 2), 2, '.', ',')."</td>";
                                      echo "</tr>";
                                    }
                                  }
                                }
                              }
                            }
                          }

                          echo"</tbody>
                        </table>
                        <div class='divider'></div>
                        <div class='container'>
                        <br>
                        <h6 class='left'>Subtotal: </h6>
                        <h6 class='right'>₱ ".number_format(Round($cart_total, 2), 2, '.', ',')."</h6>
                        <br>
                        </div>
                        <br>
                        <div class='divider'></div>
                        <br>
                        <div class='container'>
                        <h6 class='left'><b>Total:</b><br><small>(VAT incl.)</small></h6>
                        <h6 class='right teal-text'><b>₱ ".number_format(Round($cart_total, 2), 2, '.', ',')."</b></h6>
                        </div>
                        <br><br>
                      </div>
                    </div>
                    <div class='col s12 center'>
                    <input type='hidden' name='cart_total' value='".number_format(Round($cart_total, 2), 2, '.', ',')."'>";
                    
                    if ($counter_get_cart_data>0){
                      echo "<button class='waves-effect waves-light btn' name='checkout_continue'>Continue</a>";
                    }

                    echo"</form>
                    </div>
                  </div>
                ";
              }else if($step == 2){
                echo"
                  <div class='step'>
                    <i class='truck icon'></i>
                    <div class='content'>
                      <div class='title'>Shipping</div>
                      <div class='description'>Choose your shipping options</div>
                    </div>
                  </div>
                  <div class='active step'>
                    <i class='payment icon'></i>
                    <div class='content'>
                      <div class='title'>Billing</div>
                      <div class='description'>Enter billing information</div>
                    </div>
                  </div>
                  </div>
                  <div class='ui attached segment'>
                  <form class='col s12 m6 l6' method='post' action='#'>
                    <p>
                    <b>Select Mode of Payment</b>
                      <div class='card-panel'>
                        <input name='group2' type='radio' id='test1' value='cod' checked />
                        <label for='test1'>Cash on Delivery</label>
                      </div>
                    </p>
                    <div class='col s12 center'>";
                    if ((isset($_COOKIE['lazada_fullname'])) || (isset($_COOKIE['lazada_address'])) || (isset($_COOKIE['lazada_mobile']))){
                      echo "<button class='waves-effect waves-light btn' name='billing_btn'>Place Order</button>";
                    }
                    echo"</div>
                  </form>
                  <form class='col s12 m6 l6' method='post' action='#'>
                    <p>
                    <b>Apply Voucher?</b>
                        <div class='input-field col s12'>
                          <input id='voucher' type='text' name='voucher'"; if($voucher_status == true) { echo "value='".$voucher."'"; echo "disabled "; } echo"class='validate'>
                          <label for='voucher'>Code</label>
                          "; if($voucher_status == true) { echo "Deduction: ₱" . $deduct; }
                        echo"</div>
                    </p>
                    <div class='col s12 center'>
                      <button class='waves-effect waves-light btn' name='applyvoucher'";  if($voucher_status == true) { echo "disabled"; }  echo ">Apply Voucher</button>
                    </div>
                  </form>
                ";
              }
            }
          ?>

          
				</div>
        </div>
	   </div>
	</div>
  </main>
  
  <footer class="page-footer teal">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2016 Lozodo lol
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
    </footer>

  <!-- Login Modal Structure -->
  <div id="login_modal" class="modal modal-fixed-footer">
  
    <form method="post" class="signin" action="#" class="row s12">
        
          <div class="col" style="margin: 50px 30px 30px 30px;">
          <h4 align="center">User Login</h4><br>
            <div class="col">
            <div class="input-field col s6">
              <input id="last_name" type="text" class="validate" name="login_username">
              <label for="last_name">Username</label>
            </div>
            <div class="input-field col s6">
              <input id="last_name" type="password" class="validate" name="login_password">
              <label for="last_name">Password</label>
            </div>
          <br><br>
          <center>
           <button class="btn waves-effect waves-light" name="loginbtn" type="submit">Login
            <i class="material-icons right">send</i>
            </button>
           <a class="waves-effect waves-light btn modal-trigger" href="#registermodal"><i class="material-icons right">cloud</i>Register</a></center>
          </div>
          </div>
          </form>
  </div>

    <div id="registermodal" class="modal modal-fixed-footer">
    <form method="post" class="signin" action="#" class="row s12">
        
          <div class="col" style="margin: 30px 30px 30px 30px;">
            <div class="col">
            <div class="input-field col s6">
              <input id="username" type="text" class="validate" name="reg_username" autocomplete="off"required>
              <label for="username">Username</label>
            </div>
            <div class="input-field col s6">
              <input id="password" type="password" class="validate" name="reg_password" autocomplete="off" required>
              <label for="password">Password</label>
            </div>
            <div class="input-field col s6">
              <input id="re-password" type="password" class="validate" name="reg_repassword" autocomplete="off" required>
              <label for="re-password">Re-Password</label>
            </div>
            <div class="input-field col s6">
              <input id="first_name" type="text" class="validate" name="reg_fname" autocomplete="off" required>
              <label for="first_name">First Name</label>
            </div>
            <div class="input-field col s6">
              <input id="last_name" type="text" class="validate" name="reg_lname" autocomplete="off" required>
              <label for="last_name">Last Name</label>
            </div>
            <div class="input-field col s6">
              <input id="email" type="email" class="validate" name="reg_email" autocomplete="off" required>
              <label for="email">E-mail</label>
            </div>
            <div class="input-field col s12">
              <select name="reg_gender" required>
                <option value="" disabled selected>Choose an option</option>
                <option value="1">Male</option>
                <option value="0">Female</option>
              </select>
              <label>Gender</label>
            </div>
            
          <center>
           <button class="btn waves-effect waves-light" type="submit" name="registersubmit">Register
            <i class="material-icons right">send</i>
            </button>
          </center>
          </div>
          </div>
          </form>
      </div>
	
	<!--  Scripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.js"><\/script>'); }
    </script>
    <script src="js/jquery.timeago.min.js"></script>
    <script src="js/prism.js"></script>
    <script src="jade/lunr.min.js"></script>
    <script src="jade/search.js"></script>
    <script src="bin/materialize.js"></script>
    <script src="js/init.js"></script>	
	
</body>
</html>