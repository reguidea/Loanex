<?php

  include('../../dbconn.php');
  session_start();

  if(!isset($_SESSION['staffusername'])){
    echo "<script>alert('You must be staff in to enter this page!'); window.location = '../index.php';</script>";
  }else{
    $admin = "SELECT * FROM users WHERE username = '$_SESSION[staffusername]' AND position = '2'";
    $result_admin = mysqli_query($conn, $admin);
    if ($result_admin){
      $counter_admin = mysqli_num_rows($result_admin);
      if ($counter_admin>0){

      }else{
        unset($_SESSION['staffusername']);
        echo "<script>alert('You must be an admin to enter this page!'); window.location = '../index.php';</script>";
      }
    }
  }

  if(isset($_POST['update_user'])){
    $update_id = addslashes($_POST['id']);
    $update_fname = addslashes($_POST['fname']);
    $update_lname = addslashes($_POST['lname']);
    $update_email = addslashes($_POST['email']);
    $update_gender = addslashes($_POST['gender']);
    $update_address = addslashes($_POST['address']);
    $update_mobile = addslashes($_POST['mobile']);
    $update_zip = addslashes($_POST['zip']);
    $update_position = addslashes($_POST['position']);

    //echo "fname: " . $update_fname . " lname: " . $update_lname . " email: " . $update_email . " gender: " . $update_gender . " address: " . $update_address . " mobile: " . $update_mobile . " zip: " . $update_zip . " position: " . $update_position;

    if((!isset($update_fname)) || (!isset($update_lname)) || (!isset($update_email)) || (!isset($update_gender)) || (!isset($update_address)) || (!isset($update_zip)) || (!isset($update_position))){
      echo "<script>alert('Some required fields are empty')</script>";
    }else{
      $update_query = "UPDATE users SET fname = '$update_fname', lname = '$update_lname', email = '$update_email', gender = '$update_gender', default_address = '$update_address', mobile = '$update_mobile', zip = '$update_zip', position = '$update_position' WHERE id = '$update_id' ";
      $result_update_query = mysqli_query($conn, $update_query);
      if ($result_update_query){
        echo "<script>alert('Successfully Updated!')</script>";
      }else{
        echo "<script>alert('Failed to Update! ')</script>";
        echo mysqli_error($conn);
      }
    }

  }

  if(isset($_POST['btnupdatepass'])){
    $update_id = addslashes($_POST['id']);
    $update_pass = md5(addslashes($_POST['password']));
    $update_newpass = md5(addslashes($_POST['newpass']));
    $update_renewpass = md5(addslashes($_POST['renewpass']));

    if((empty($update_pass)) || (empty($update_newpass)) || (empty($update_renewpass))){
      echo "<script>alert('Some fields are empty!');</script>";
    }else{
      if ($update_newpass != $update_renewpass){
        echo "<script>alert('New Password not match!');</script>";
      }else{
        $check_curr = "SELECT * FROM users WHERE id = '$update_id' AND password = '$update_pass'";
        $result_check_curr = mysqli_query($conn, $check_curr);
        if ($result_check_curr){
          $counter_check_curr = mysqli_num_rows($result_check_curr);
          if ($counter_check_curr>0){
            $update_password = "UPDATE users SET password = '$update_newpass' WHERE id = '$update_id' AND password = '$update_pass'";
            $result_update_password = mysqli_query($conn, $update_password);
            if ($result_update_password){
              echo "<script>alert('Successfully updating your password!');</script>";
            }else{
              echo "<script>alert('Failed to update your password');</script>";
            }
          }else{
            echo "<script>alert('Current Password Mismatch!');</script>";
          }
        }
      }
    }
  }

  if(isset($_POST['delete_user'])){
    $delete_id = $_POST['id'];

    $delete_user = "DELETE FROM users WHERE id = '$delete_id'";
    $result_delete_user = mysqli_query($conn, $delete_user);
    $delete_user_reviews = "DELETE FROM reviews WHERE userid = '$delete_id'";
    $result_delete_user_reviews = mysqli_query($conn, $delete_user_reviews);
    $delete_checkout_data = "DELETE FROM checkout_data WHERE username = '$_SESSION[username]'";
    $result_delete_checkout_data = mysqli_query($conn, $delete_checkout_data);
    $delete_checkout_package = "DELETE FROM checkout_package WHERE username = '$_SESSION[username]'";
    $result_delete_checkout_package = mysqli_query($conn, $delete_checkout_package);
    if ($result_delete_user && $result_delete_user_reviews && $result_delete_checkout_data && $result_delete_checkout_package){
      echo "<script>alert('User Successfully Deleted');</script>";
    }else{
      echo "<script>alert('Failed to Delete User');</script>";
    }
  }

?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content=" description here ">
    <title></title>
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
    <!--  Android 5 Chrome Color-->
    <meta name="theme-color" content="#009688">
    <!-- CSS-->
    <link href="../../css/prism.css" rel="stylesheet">
    <link href="../../css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="../../js/sidemenu.js"></script>
    <script src="../../ckeditor/ckeditor.js"></script>

<style>
  body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }

  nav ul li a:hover, nav ul li.active {
    background-color: #00695c;
  }
      
</style>
</head>
<body>

   <header>
      <div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only"><i class="material-icons" style="padding-top: 8px">menu</i></a></div>
      <ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="#" class="brand-logo">
            <img id="front-page-logo" src="images/logo.png"></a></li>
        <li class='bold'><a href='index.php' class='waves-effect waves-teal'>Home</a></li>
        <?php
        if(!isset($_SESSION['staffusername'])){
         echo "<script>alert('You must be logged in to enter this page!'); window.location: '../index.php';</script>";
        }else{
          echo "<li class='bold'><a href='../logout.php' class='waves-effect waves-teal'>Logout</a></li>";
        }
        ?>
    <li>&nbsp; &nbsp;Categories</li>
    <li class="no-padding">
        <ul class="collapsible collapsible-accordion">
        <?php

          $load_maincategory_query = "SELECT * FROM categories";
          $result_maincategory = mysqli_query($conn, $load_maincategory_query);
          if ($result_maincategory){
            $counter_maincategory = mysqli_num_rows($result_maincategory);
              if ($counter_maincategory>0){
                while($row = mysqli_fetch_assoc($result_maincategory)){
                $maincategory_id = $row['id'];
                $maincategory_name = $row['categoryname'];
                  echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>".$maincategory_name."</a>";
                  $load_subcategory_query = "SELECT * FROM subcategories WHERE categoryid = '$maincategory_id'";
                  $result_subcategory = mysqli_query($conn, $load_subcategory_query);
                  if ($result_subcategory){
                    $counter_subcategory = mysqli_num_rows($result_subcategory);
                    if ($counter_subcategory>0){
                      while($row2 = mysqli_fetch_assoc($result_subcategory)){
                      $subcategory_maincategoryid = $row2['categoryid'];
                      $subcategory_name = $row2['subcategoryname'];
                      $subcategory_id = $row2['id'];
                      $get_items_on_this_category = "SELECT * FROM items WHERE categoryid = $maincategory_id AND subcategoryid = $subcategory_id";
                      $result_items_on_this_category = mysqli_query($conn, $get_items_on_this_category);
                      if ($result_items_on_this_category){
                        $counter_items_on_this_category = mysqli_num_rows($result_items_on_this_category);
                        echo"                       
                          <div class='collapsible-body'>
                                <ul>
                          <li><a href='#'>".$subcategory_name." (".$counter_items_on_this_category.")</a></li>
                                </ul>
                              </div>";
                      }
                      }
                    }else{
                      echo"                       
                          <div class='collapsible-body'>
                                <ul>
                          <li><a href='#'>Failed to load</a></li>
                                </ul>
                              </div>";
                    }
                  }
                }
              }else{
                echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>Failed to load</a>";
              }
          }



        ?>
        </li>
            
      </ul>
    </li>
    </header>

  <nav>
    <div class="nav-wrapper teal">
      <a href="#" class="brand-logo"><img id="front-page-logo" src="images/logo.png"></a>
      <ul class="right hide-on-med-and-down">
      <?php
      if(isset($_SESSION['staffusername'])){
        echo"<li><a class='waves-effect waves-light' href='../logout.php'>Logout<i class='left material-icons'>send</i></a></li>";
      }else{
         echo "<script>alert('You must be logged in to enter this page!'); window.location: '../index.php';</script>";
      }

      ?>
      </ul>
    </div>
  </nav>
  
  <main>
    <div class="container">
      <div class="row">
        <div class='col s12'>
        <br><br>
          <div class='center'>
          <a href='index.php' class="waves-effect waves-light btn">Items</a>
          <a href='shipping.php' class="waves-effect waves-light btn">Shipping</a>
          <a class="waves-effect waves-light btn">Users</a>
          <a href='maincategory.php' class="waves-effect waves-light btn">Main Category</a>
          <a href='subcategory.php' class="waves-effect waves-light btn">Sub Category</a>
          </div>
        <br><br>
        <table class='centered responsive-table'>
          <thead>
            <tr>
                <th data-field="btn"> Manage </th>
                <th data-field="fname">First Name</th>
                <th data-field="lname">Last Name</th>
                <th data-field="email">Email</th>
                <th data-field="gender">Gender</th>
                <th data-field="username">Username</th>
                <th data-field="address">Address</th>
                <th data-field="mobile">Mobile</th>
                <th data-field="zip">Zip</th>
                <th data-field="position">Position</th>
            </tr>
          </thead>

          <tbody>
          <?php
          $total = 0;
          $package = "SELECT * FROM users";
          $result_package = mysqli_query($conn, $package);
          if ($result_package){
            $counter_package = mysqli_num_rows($result_package);
            if ($counter_package>0){
              while($row3 = mysqli_fetch_assoc($result_package)){
                $uid = $row3['id'];
                $ufname = $row3['fname'];
                $ulname = $row3['lname'];
                $uemail = $row3['email'];
                $ugender = $row3['gender'];
                $uusername = $row3['username'];
                $uaddress = $row3['default_address'];
                $umobile = $row3['mobile'];
                $uzip = $row3['zip'];
                $uposition = $row3['position'];
                $uimglink = $row3['imglink'];
                echo "
                  <tr>
                    <td><a data-uid='".$uid."' data-fname='".$ufname."' data-lname='".$ulname."' data-email='".$uemail."' data-gender='".$ugender."' data-username='".$uusername."' data-address='".$uaddress."' data-mobile='".$umobile."' data-zip='".$uzip."' data-position='".$uposition."' href='#manage_modal' class='modal-trigger btn-floating btn-small waves-effect waves-light teal'><i class='material-icons'>mode_edit</i></a>
                    <a data-uid='".$uid."' href='#edit_password' class='modal-trigger btn-floating btn-small waves-effect waves-light teal'><i class='material-icons'>lock_outline</i></a></td>
                    <td>".$ufname."</td>
                    <td>".$ulname."</td>
                    <td>".$uemail."</td>
                    <td>".$ugender."</td>
                    <td>".$uusername."</td>
                    <td>".$uaddress."</td>
                    <td>".$umobile."</td>
                    <td>".$uzip."</td>
                    <td>".$uposition."</td>
                  </tr>";
            }
          }
        }
          ?>
          </tbody>
        </table>
        </div>
      </div>
    </div>
  </main>
  
  <footer class="page-footer teal">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2016 Lozodo lol
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
    </footer>


  <div id="edit_password" class="modal">
    <div class="modal-content">
      <h5>Edit Password</h5>
        <form method='post' action='#' class='col s12'>
          <div class="row getvalue">
          <input type='hidden' name='id' id='id'>
            <div class="input-field col s12">
              <input id="password" name='password' type="password" class="validate" required>
              <label for="password">Current Password</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="newpass" name='newpass' type="password" class="validate" required>
              <label for="newpass">New Password</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
              <input id="renewpass" name='renewpass' type="password" class="validate" required>
              <label for="renewpass">Retype New Password</label>
            </div>
          </div>
          <div class="row">
            <div class="col s12 center">
              <button name='btnupdatepass' class="waves-effect waves-light btn">Update</a>
            </div>
          </div>
        </form>
    </div>
  </div>

    <div id="manage_modal" class="modal">
      <div class="modal-content">
        <div class='col s12 getvalue'>
          <h4 class='center'>User Edit</h4>
          <form method='post' action='#'>
            <div class="row">
            <input type='hidden' name='id' id='id'>
              <div class="input-field col s12">
                <input id="username" type="text" disabled>
                <label for="username">Username</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input id="fname" type="text" name='fname' required>
                <label for="fname">First Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input id="lname" type="text" name='lname' required>
                <label for="lname">Last Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input id="email" type="email" name='email' required>
                <label for="email">Email</label>
              </div>
            </div>
            <div class='row'>
              <div class="col s12">
                Gender:
                  <p>
                    <input name='gender' type='radio' id='g-male' value='1'/>
                    <label for='g-male'>Male</label>
                  </p>
                  <p>
                    <input name='gender' type='radio' id='g-female' value='0'/>
                    <label for='g-female'>Female</label>
                  </p>
              </div>
            </div>
            <div class="row">
                <div class="row">
                  <div class="input-field col s12">
                    <textarea id="address" name='address' class="materialize-textarea" required></textarea>
                    <label for="address">Address</label>
                  </div>
                </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input id="mobile" type="number" name='mobile'>
                <label for="mobile">Mobile</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input id="zip" type="text" name='zip' required>
                <label for="zip">Zip</label>
              </div>
            </div>
            <div class='row'>
              <div class="col s12">
                Position:
                  <p>
                    <input name='position' type='radio' id='p-normal' value='0'/>
                    <label for='p-normal'>Normal User</label>
                  </p>
                  <p>
                    <input name='position' type='radio' id='p-mod' value='1'/>
                    <label for='p-mod'>Staff</label>
                  </p>
                  <p>
                    <input name='position' type='radio' id='p-admin' value='2'/>
                    <label for='p-admin'>Administrator</label>
                  </p>
              </div>
            </div>
            <div class='row'>
              <div class='col s12'>
                <div class='center'>
                  <button name='update_user' class="waves-effect waves-light btn">Update</button>
                  <button name='delete_user' class="waves-effect waves-light btn">Delete</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  
  <!--  Scripts-->
    <script src="../../js/jquery-2.1.4.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="../../bin/jquery-2.1.1.min.js"><\/script>'); }
    </script>
    <script src="../../js/jquery.timeago.min.js"></script>
    <script src="../../js/prism.js"></script>
    <script src="../../jade/lunr.min.js"></script>
    <script src="../../jade/search.js"></script>
    <script src="../../bin/materialize.js"></script>
    <script src="../../js/init.js"></script>
    <script>
    $(document).on('click', '.modal-trigger', function () {
       var uid = $(this).data('uid');
       $('.getvalue #id').val( uid );
       var username = $(this).data('username');
       $('.getvalue #username').val( username );
       var fname = $(this).data('fname');
       $('.getvalue #fname').val( fname );
       var lname = $(this).data('lname');
       $('.getvalue #lname').val( lname );
       var email = $(this).data('email');
       $('.getvalue #email').val( email );
       var address = $(this).data('address');
       $('.getvalue #address').val( address );
       var mobile = $(this).data('mobile');
       $('.getvalue #mobile').val( mobile );
       var zip = $(this).data('zip');
       $('.getvalue #zip').val( zip );
       var gender = $(this).data('gender');
       var position = $(this).data('position');
       if (gender == 1){
        $('#g-male').prop('checked', true);
       }else{
        $('#g-female').prop('checked', true);
       }
       if (position == 1){
        $('#p-mod').prop('checked', true);
       }else if(position == 2){
        $('#p-admin').prop('checked', true);
       }else{
        $('#p-normal').prop('checked', true);
       }
       Materialize.updateTextFields();
       $('#manage_modal').modal('show');
    });
    </script>
  
</body>
</html>