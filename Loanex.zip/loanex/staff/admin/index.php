<?php

  include('../../dbconn.php');
  session_start();

  if(!isset($_SESSION['staffusername'])){
    echo "<script>alert('You must be logged in to enter this page!'); window.location = '../index.php';</script>";
  }else{
    $admin = "SELECT * FROM users WHERE username = '$_SESSION[staffusername]' AND position = '2'";
    $result_admin = mysqli_query($conn, $admin);
    if ($result_admin){
      $counter_admin = mysqli_num_rows($result_admin);
      if ($counter_admin>0){

      }else{
        unset($_SESSION['staffusername']);
        echo "<script>alert('You must be an admin to enter this page!'); window.location = '../index.php';</script>";
      }
    }
  }

  if(isset($_POST['btn_update'])){
    $update_id = $_POST['item_id'];
    $update_name = $_POST['item_name'];
    $update_description = $_POST['item_description'];
    $update_stocks = $_POST['item_stocks'];
    $update_price = $_POST['item_price'];
    $update_discount = $_POST['item_discount'];
    $update_categoryid = $_POST['item_categoryid'];
    $update_method = $_POST['item_cod'];
    if (!empty($update_categoryid)){
      if(isset($_POST['item_subcategoryid'])){
      $update_subcategoryid = $_POST['item_subcategoryid'];

      $update_item = "UPDATE items SET name = '$update_name', description = '$update_description', qty = '$update_stocks', price = '$update_price',  categoryid = '$update_categoryid', subcategoryid = '$update_subcategoryid', discount = '$update_discount', cod_available = '$update_method' WHERE id = '$update_id'";
      $result_update_item = mysqli_query($conn, $update_item);
      if($result_update_item){
        echo "<script>alert('Successfully Updated')</script>";
      }else{
        echo "<script>alert('Error!')</script>";
        echo mysqli_error($conn);
      }

      }else{
        echo "<script>alert('You must select a Sub Category!')</script>";
      }
    }else{
      echo "<script>alert('You must select a Main Category!')</script>";
    }



  }

  if(isset($_POST['btn_add'])){
    $add_item_name = addslashes($_POST['additem_name']);
    $add_item_desc = addslashes($_POST['additem_description']);
    $add_item_stocks = $_POST['additem_stocks'];
    $add_item_price = $_POST['additem_price'];
    $add_item_category = $_POST['additem_category'];
    $add_item_category_explode = explode('|', $add_item_category);
    $add_item_maincategory = $add_item_category_explode[0];
    $add_item_subcategory = $add_item_category_explode[1];
    $add_item_discount = $_POST['additem_discount'];
    $add_item_method = $_POST['additem_cod'];

    $add_item_query = "INSERT INTO items (name, description, price, qty, categoryid, discount, subcategoryid, cod_available) VALUES ('$add_item_name', '$add_item_desc', '$add_item_price', '$add_item_stocks', '$add_item_maincategory', '$add_item_discount', '$add_item_subcategory', '$add_item_method')";

    $result_add_item_query = mysqli_query($conn, $add_item_query);
    if ($result_add_item_query){
      echo "<script>alert('Item Successfully Added')</script>";
    }else{
      echo "<script>alert('Failed to add item')</script>";
    }

  }

  if(isset($_POST['btnupdatephoto'])){
  $photo_itemid = $_POST['photo_itemid'];
  $target_dir = "../../images/items/";
  $uploadimg_dir = "images/items/";
  if(!is_dir($target_dir)) {
    mkdir($target_dir);
    }
  $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
  $uploadOk = 1;
  $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
  // Check if image file is a actual image or fake image
  if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
  }
  // Check if file already exists
  if (file_exists($target_file)) {
    echo "<script type='text/javascript'>
              alert('Sorry file already exist! Try to rename the file and try again')
              window.location = 'index.php'
              </script>";
    $uploadOk = 0;
  }
  // Check file size
  if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo"<script type='text/javascript'>
              alert('File too large!')
              window.location = 'index.php'
              </script>";
    $uploadOk = 0;
  }
  // Allow certain file formats
  if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
  && $imageFileType != "gif" ) {
    echo"<script type='text/javascript'>
              alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed!')
              window.location = 'index.php'
              </script>";
    $uploadOk = 0;
  }
  // Check if $uploadOk is set to 0 by an error
  if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
  // if everything is ok, try to upload file
  } else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
      //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
      $nameandir = $uploadimg_dir.basename( $_FILES["fileToUpload"]["name"]);
      $update_photo_query = mysqli_query($conn ,"UPDATE items SET imglink = '$nameandir' WHERE id = '$photo_itemid'");
      if($update_photo_query){
        echo"<script type='text/javascript'>
              alert('Item Photo Updated!')
              window.location = 'index.php'
              </script>";
      }else{
        echo"<script type='text/javascript'>
              alert('Item Photo Update Unsucessful!')
              window.location = 'index.php'
              </script>";
      }
    } else {
      echo "<script type='text/javascript'>
              alert('Error! Photo cannot be uploaded!')
              window.location = 'index.php'
              </script>";
    }
  }
  
  }

  if(isset($_POST['btn_delete'])){

    $delete_itemid = $_POST['item_id'];

    $delete_query = "DELETE FROM items WHERE id = '$delete_itemid'";
    $result_delete_query = mysqli_query($conn, $delete_query);

    if ($result_delete_query){
      echo "<script>alert('Item successfully deleted!');</script>";
    }else{
      echo "<script>alert('Failed to delete!');</script>";
    }

  }

?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content=" description here ">
    <title></title>
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
    <!--  Android 5 Chrome Color-->
    <meta name="theme-color" content="#009688">
    <!-- CSS-->
    <link href="../../css/prism.css" rel="stylesheet">
    <link href="../../css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="../../js/sidemenu.js"></script>
    <script src="../../ckeditor/ckeditor.js"></script>

<style>
  body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }

  nav ul li a:hover, nav ul li.active {
    background-color: #00695c;
  }
      
</style>
</head>
<body>

   <header>
      <div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only"><i class="material-icons" style="padding-top: 8px">menu</i></a></div>
      <ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="#" class="brand-logo">
            <img id="front-page-logo" src="images/logo.png"></a></li>
        <li class='bold'><a href='index.php' class='waves-effect waves-teal'>Home</a></li>
        <?php
        if(!isset($_SESSION['staffusername'])){
         echo "<script>alert('You must be logged in to enter this page!'); window.location: '../index.php';</script>";
        }else{
          echo "<li class='bold'><a href='../logout.php' class='waves-effect waves-teal'>Logout</a></li>";
        }
        ?>
    <li>&nbsp; &nbsp;Categories</li>
    <li class="no-padding">
        <ul class="collapsible collapsible-accordion">
        <?php

          $load_maincategory_query = "SELECT * FROM categories";
          $result_maincategory = mysqli_query($conn, $load_maincategory_query);
          if ($result_maincategory){
            $counter_maincategory = mysqli_num_rows($result_maincategory);
              if ($counter_maincategory>0){
                while($row = mysqli_fetch_assoc($result_maincategory)){
                $maincategory_id = $row['id'];
                $maincategory_name = $row['categoryname'];
                  echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>".$maincategory_name."</a>";
                  $load_subcategory_query = "SELECT * FROM subcategories WHERE categoryid = '$maincategory_id'";
                  $result_subcategory = mysqli_query($conn, $load_subcategory_query);
                  if ($result_subcategory){
                    $counter_subcategory = mysqli_num_rows($result_subcategory);
                    if ($counter_subcategory>0){
                      while($row2 = mysqli_fetch_assoc($result_subcategory)){
                      $subcategory_maincategoryid = $row2['categoryid'];
                      $subcategory_name = $row2['subcategoryname'];
                      $subcategory_id = $row2['id'];
                      $get_items_on_this_category = "SELECT * FROM items WHERE categoryid = $maincategory_id AND subcategoryid = $subcategory_id";
                      $result_items_on_this_category = mysqli_query($conn, $get_items_on_this_category);
                      if ($result_items_on_this_category){
                        $counter_items_on_this_category = mysqli_num_rows($result_items_on_this_category);
                        echo"                       
                          <div class='collapsible-body'>
                                <ul>
                          <li><a href='#'>".$subcategory_name." (".$counter_items_on_this_category.")</a></li>
                                </ul>
                              </div>";
                      }
                      }
                    }else{
                      echo"                       
                          <div class='collapsible-body'>
                                <ul>
                          <li><a href='#'>Failed to load</a></li>
                                </ul>
                              </div>";
                    }
                  }
                }
              }else{
                echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>Failed to load</a>";
              }
          }



        ?>
        </li>
            
      </ul>
    </li>
    </header>

  <nav>
    <div class="nav-wrapper teal">
      <a href="#" class="brand-logo"><img id="front-page-logo" src="images/logo.png"></a>
      <ul class="right hide-on-med-and-down">
      <?php
      if(isset($_SESSION['staffusername'])){
        echo"<li><a class='waves-effect waves-light' href='../logout.php'>Logout<i class='left material-icons'>send</i></a></li>";
      }else{
         echo "<script>alert('You must be logged in to enter this page!'); window.location: '../index.php';</script>";
      }

      ?>
      </ul>
    </div>
  </nav>
  
  <main>
    <div class="container">
      <div class="row">
        <div class="col s12">
        <br><br>
          <div class='center'>
          <a class="waves-effect waves-light btn">Items</a>
          <a href='shipping.php' class="waves-effect waves-light btn">Shipping</a>
          <a href='users.php' class="waves-effect waves-light btn">Users</a>
          <a href='maincategory.php' class="waves-effect waves-light btn">Main Category</a>
          <a href='subcategory.php' class="waves-effect waves-light btn">Sub Category</a>
          </div>
        <br><br>
          <table class="highlight centered responsive-table">
            <thead>
              <tr>
                  <th data-field="buttons"><a href='#create_modal' class='modal-trigger btn-floating waves-effect waves-light'><i class='material-icons'>add</i></a></th>
                  <th data-field="id">ID</th>
                  <th data-field="name">Item Name</th>
                  <th data-field="qty">Stocks</th>
                  <th data-field="price">Price</th>
                  <th data-field="category">Category</th>
                  <th data-field="subcategory">Sub Category</th>
                  <th data-field="discount">Discount</th>
                  <th data-field="discount">COD Available?</th>
                  <th data-field="img">Header Img</th>
              </tr>
            </thead>
            <tbody>
            <?php
              $load_items = "SELECT * FROM items ORDER BY id DESC";
              $result_load_items = mysqli_query($conn, $load_items);
              if($result_load_items){
                $counter_load_items = mysqli_num_rows($result_load_items);
                if ($counter_load_items>0){
                  while($row3 = mysqli_fetch_assoc($result_load_items)){
                    $item_id = $row3['id'];
                    $item_name = $row3['name'];
                    $item_description = $row3['description'];
                    $item_price = $row3['price'];
                    $item_qty = $row3['qty'];
                    $item_categoryid = $row3['categoryid'];
                    $get_categoryname = "SELECT * FROM categories WHERE id = '$item_categoryid'";
                    $result_get_categoryname = mysqli_query($conn, $get_categoryname);
                    if($result_get_categoryname){
                      $counter_get_categoryname = mysqli_num_rows($result_get_categoryname);
                      if($counter_get_categoryname>0){
                        while($row4 = mysqli_fetch_assoc($result_get_categoryname)){
                          $item_categoryname = $row4['categoryname'];
                        }
                      }
                    }
                    $item_subcategoryid = $row3['subcategoryid'];
                    $get_subcategoryname = "SELECT * FROM subcategories WHERE id = '$item_subcategoryid' AND categoryid = '$item_categoryid'";
                    $result_get_subcategoryname = mysqli_query($conn, $get_subcategoryname);
                    if($result_get_subcategoryname){
                      $counter_get_subcategoryname = mysqli_num_rows($result_get_subcategoryname);
                      if($counter_get_subcategoryname>0){
                        while($row5 = mysqli_fetch_assoc($result_get_subcategoryname)){
                          $item_subcategoryname = $row5['subcategoryname'];
                        }
                      }
                    }
                    $item_discount = $row3['discount'];
                    $item_imglink = $row3['imglink'];
                    $item_cod = $row3['cod_available'];
                    echo"
                    <tr>
                      <td>
                        <a href='#manage_modal' class='modal-trigger btn-floating waves-effect waves-light' data-id='".$item_id."' data-name='".$item_name."' data-description='".$item_description."' data-stocks='".$item_qty."' data-price='".$item_price."' data-categoryname='".$item_categoryname."' data-subcategoryname='".$item_subcategoryname."' data-discount='".$item_discount."' data-cod='".$item_cod."'><i class='material-icons'>mode_edit</i></a>
                        <a href='#editphoto_modal' data-photoitemid='".$item_id."' class='modal-trigger btn-floating waves-effect waves-light'><i class='material-icons'>insert_photo</i></a>
                      </td>
                      <td>".$item_id."</td>
                      <td>".$item_name."</td>
                      <td>".$item_qty."</td>
                      <td>".$item_price."</td>
                      <td>".$item_categoryname."</td>
                      <td>".$item_subcategoryname."</td>
                      <td>".$item_discount."%</td>
                      <td>".$item_cod."</td>
                      <td><img class='materialboxed responsive-img' width='100' height='50' src='../../".$item_imglink."'></td>
                    </tr>
                    ";
                  }
                }
              }
            ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  
  <footer class="page-footer teal">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2016 Lozodo lol
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
    </footer>

  <!-- Login Modal Structure -->
  <div id="login_modal" class="modal modal-fixed-footer">
  
    <form method="post" class="signin" action="#" class="row s12">
        
          <div class="col" style="margin: 50px 30px 30px 30px;">
          <h4 align="center">User Login</h4><br>
            <div class="col">
            <div class="input-field col s6">
              <input id="last_name" type="text" class="validate" name="login_username">
              <label for="last_name">Username</label>
            </div>
            <div class="input-field col s6">
              <input id="last_name" type="password" class="validate" name="login_password">
              <label for="last_name">Password</label>
            </div>
          <br><br>
          <center>
           <button class="btn waves-effect waves-light" name="loginbtn" type="submit">Login
            <i class="material-icons right">send</i>
            </button>
           <a class="waves-effect waves-light btn modal-trigger" href="#registermodal"><i class="material-icons right">cloud</i>Register</a></center>
          </div>
          </div>
          </form>
  </div>

    <div id="registermodal" class="modal modal-fixed-footer">
    <form method="post" class="signin" action="#" class="row s12">
        
          <div class="col" style="margin: 30px 30px 30px 30px;">
            <div class="col">
            <div class="input-field col s6">
              <input id="username" type="text" class="validate" name="reg_username" autocomplete="off"required>
              <label for="username">Username</label>
            </div>
            <div class="input-field col s6">
              <input id="password" type="password" class="validate" name="reg_password" autocomplete="off" required>
              <label for="password">Password</label>
            </div>
            <div class="input-field col s6">
              <input id="re-password" type="password" class="validate" name="reg_repassword" autocomplete="off" required>
              <label for="re-password">Re-Password</label>
            </div>
            <div class="input-field col s6">
              <input id="first_name" type="text" class="validate" name="reg_fname" autocomplete="off" required>
              <label for="first_name">First Name</label>
            </div>
            <div class="input-field col s6">
              <input id="last_name" type="text" class="validate" name="reg_lname" autocomplete="off" required>
              <label for="last_name">Last Name</label>
            </div>
            <div class="input-field col s6">
              <input id="email" type="email" class="validate" name="reg_email" autocomplete="off" required>
              <label for="email">E-mail</label>
            </div>
            <div class="input-field col s12">
              <select name="reg_gender" required>
                <option value="" disabled selected>Choose an option</option>
                <option value="1">Male</option>
                <option value="0">Female</option>
              </select>
              <label>Gender</label>
            </div>
            
          <center>
           <button class="btn waves-effect waves-light" type="submit" name="registersubmit">Register
            <i class="material-icons right">send</i>
            </button>
          </center>
          </div>
          </div>
          </form>
      </div>

  <!-- Modal Structure -->
  <div id="manage_modal" class="modal">
    <div class="modal-content">
      <h4>Manage</h4>
        <div class="row getvalue">
          <form class="col s12" method='post' action='#'>
            <div class="row">
              <div class="input-field col s12">
                <input id="item_id" name="item_id" type="hidden" class="validate">
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input value="" id="item_name" name='item_name' type="text" class="validate">
                <label for="item_name">Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
              Description: 
                <textarea id="item_description" name='item_description' class="materialize-textarea"></textarea>
                <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'item_description');

            </script>
            </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input value="" id="item_stocks" name='item_stocks' type="number" class="validate">
                <label for="item_stocks">Stocks</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input value="" id="item_price" name='item_price' type="number" step="0.01" class="validate">
                <label for="item_price">Price</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s6">
                <select id="search_category_id" name='item_categoryid'>
                  <option value="" selected>Choose your option</option>
                  <?php
                  $get_main_categories = "SELECT * FROM categories";
                  $result_get_main_categories = mysqli_query($conn, $get_main_categories);
                  if($result_get_main_categories){
                    $counter_get_main_categories = mysqli_num_rows($result_get_main_categories);
                    if($counter_get_main_categories>0){
                      while($row5 = mysqli_fetch_assoc($result_get_main_categories)){
                        $select_categoryid = $row5['id'];
                        $select_categoryname = $row5['categoryname'];
                        echo "<option value='".$select_categoryid."'>".$select_categoryname."</option>";
                      }
                    }
                  }

                  ?>
                </select>
                <label>Main Category</label>
              </div>
              <div class="input-field col s6">
                <div id="show_sub_categories">
                  <div class="preloader-wrapper active" id="loader">
                    <div class="spinner-layer spinner-red-only">
                      <div class="circle-clipper left">
                      <div class="circle"></div>
                      </div><div class="gap-patch">
                      <div class="circle"></div>
                      </div><div class="circle-clipper right">
                      <div class="circle"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s12">
                  <input value="" id="item_discount" name='item_discount' type="number" max="100" class="validate">
                  <label for="item_discount" data-error="Decimals are not allowed, Range: 0-100">Discount</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s12">
                  <input value="" id="item_cod" name='item_cod' type="number" max="1" class="validate">
                  <label for="item_cod" data-error="1 - True; 0 - False">COD Available?</label>
                </div>
              </div>
              <div class="row">
                <div class="col s12 center-align">
                  <button type="submit" name="btn_update" class="waves-effect waves-light btn">Update</button>
                  <button type="submit" name="btn_delete" class="waves-effect waves-light btn">Delete</button>
                </div>
              </div>
            </div>
          </form>
        </div>
    </div>
  </div>

  <!-- Modal Structure -->
  <div id="create_modal" class="modal">
    <div class="modal-content">
      <h4>Add Item</h4>
        <div class="row">
          <form class="col s12" method='post' action='#'>
            <div class="row">
              <div class="input-field col s12">
                <input value="" id="additem_name" name='additem_name' type="text" class="validate">
                <label for="additem_name">Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
              Description: 
                <textarea id="additem_description" name='additem_description' class="materialize-textarea"></textarea>
                <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'additem_description');

            </script>
            </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input value="" id="additem_stocks" name='additem_stocks' type="number" class="validate">
                <label for="additem_stocks">Stocks</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input value="" id="additem_price" name='additem_price' type="number" step="0.01" class="validate">
                <label for="additem_price">Price</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <select name='additem_category'>
                  <?php
                  $get_main_categories1 = "SELECT * FROM categories";
                  $result_get_main_categories1 = mysqli_query($conn, $get_main_categories1);
                  if($result_get_main_categories1){
                    $counter_get_main_categories1 = mysqli_num_rows($result_get_main_categories1);
                    if($counter_get_main_categories1>0){
                      while($row6 = mysqli_fetch_assoc($result_get_main_categories1)){
                        $select_categoryid1 = $row6['id'];
                        $select_categoryname1 = $row6['categoryname'];
                        echo "<optgroup label='".$select_categoryname1."'>";
                        $get_sub_categories = "SELECT * FROM subcategories WHERE categoryid = '$select_categoryid1'";
                        $result_get_sub_categories = mysqli_query($conn, $get_sub_categories);
                        if ($result_get_sub_categories){
                          $counter_get_sub_categories = mysqli_num_rows($result_get_sub_categories);
                          if ($counter_get_sub_categories){
                            while($row7 = mysqli_fetch_assoc($result_get_sub_categories)){
                              $select_subcategoryid = $row7['id'];
                              $select_subcategoryname = $row7['subcategoryname'];
                              echo "<option value='".$select_categoryid1."|".$select_subcategoryid."'>".$select_subcategoryname."</option>";
                            }
                          }
                        }
                        echo "</optgroup>";
                      }

                    }

                  }

                  ?>
                </select>
                <label>Category</label>
              </div>
            </div>
              <div class="row">
                <div class="input-field col s12">
                  <input value="" id="additem_discount" name='additem_discount' type="number" max="100" class="validate">
                  <label for="additem_discount" data-error="Decimals are not allowed, Range: 0-100">Discount</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s12">
                  <input value="" id="additem_cod" name='additem_cod' type="number" max="1" class="validate">
                  <label for="additem_cod" data-error="1 - True; 0 - False">COD Available?</label>
                </div>
              </div>
              <div class="row">
                <div class="col s12 center-align">
                  <button type="submit" name="btn_add" class="waves-effect waves-light btn">Add Item</button>
                </div>
              </div>
            </div>
          </form>
        </div>
    </div>
  </div>

  <div id="editphoto_modal" class="modal">
    <div class="modal-content">
      <div class='row getvalue'>
      <h4>Edit Photo</h4>
        <div class='col s12 center'>
          <form ENCTYPE='multipart/form-data' class="col s12" method="post" action="#">
          <input type='hidden' name='photo_itemid' id='photo_itemid'>
            <div class="file-field input-field">
              <div class="btn">
                <span>Image</span>
                <input type="file" name="fileToUpload" id="fileToUpload" accept="image/x-png, image/jpeg" required> 
              </div>
              <div class="file-path-wrapper">
                <input class="file-path validate" type="text">
              </div>
            </div>
            <button name='btnupdatephoto' class="waves-effect waves-light btn">Upload</a>
          </form>
        </div>
      </div>
    </div>
  </div>
  
  <!--  Scripts-->
    <script src="../../js/jquery-2.1.4.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="../../bin/jquery-2.1.1.min.js"><\/script>'); }
    </script>
    <script src="../../js/jquery.timeago.min.js"></script>
    <script src="../../js/prism.js"></script>
    <script src="../../jade/lunr.min.js"></script>
    <script src="../../jade/search.js"></script>
    <script src="../../bin/materialize.js"></script>
    <script src="../../js/init.js"></script> 
    <script type='text/javascript'>
    $(document).on('click', '.modal-trigger', function () {
       var id = $(this).data('id');
       $('.getvalue #item_id').val( id );
       var name = $(this).data('name');
       $('.getvalue #item_name').val( name );
       var description = $(this).data('description');
       CKEDITOR.instances['item_description'].setData(description)
       var stocks = $(this).data('stocks');
       $('.getvalue #item_stocks').val( stocks );
       var price = $(this).data('price');
       $('.getvalue #item_price').val( price );
       var discount = $(this).data('discount');
       $('.getvalue #item_discount').val( discount );
       var categoryname = $(this).data('categoryname');
       $('.getvalue #item_categoryname').val( categoryname );
       var subcategoryname = $(this).data('subcategoryname');
       $('.getvalue #item_subcategoryname').val( subcategoryname );
       var cod = $(this).data('cod');
       $('.getvalue #item_cod').val( cod );
       var photo_itemid = $(this).data('photoitemid');
       $('.getvalue #photo_itemid').val( photo_itemid );
       Materialize.updateTextFields();
       $('#manage_modal').modal('show');
    });

    $(document).ready(function() {

      $('#loader').hide();
      $('#show_heading').hide();

      $('#search_category_id').change(function(){
        $('#show_sub_categories').fadeOut();
        $('#loader').show();
        $.post("../../get_child_categories.php", {
          parent_id: $('#search_category_id').val(),
        }, function(response){
          
          setTimeout("finishAjax('show_sub_categories', '"+escape(response)+"')", 400);
        });
        return false;
      });
    });

    function finishAjax(id, response){
      $('#loader').hide();
      $('#show_heading').show();
      $('#'+id).html(unescape(response));
      $('#'+id).fadeIn();
    } 

    function alert_id()
    {
      if($('#sub_category_id').val() == '')
      alert('Please select a sub category.');
      else
      alert($('#sub_category_id').val());
      return false;
    }
    </script>
  
</body>
</html>