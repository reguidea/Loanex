<?php

session_start();
unset($_SESSION['staffusername']);
header('Location: ' . $_SERVER['HTTP_REFERER']);

?>