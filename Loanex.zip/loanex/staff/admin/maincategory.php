<?php

  include('../../dbconn.php');
  session_start();

  if(!isset($_SESSION['staffusername'])){
    echo "<script>alert('You must be logged in to enter this page!'); window.location = '../index.php';</script>";
  }else{
    $admin = "SELECT * FROM users WHERE username = '$_SESSION[staffusername]' AND position = '2'";
    $result_admin = mysqli_query($conn, $admin);
    if ($result_admin){
      $counter_admin = mysqli_num_rows($result_admin);
      if ($counter_admin>0){

      }else{
        unset($_SESSION['staffusername']);
        echo "<script>alert('You must be an admin to enter this page!'); window.location = '../index.php';</script>";
      }
    }
  }

  if(isset($_POST['btnupdate'])){
    $update_id = $_POST['id'];
    $update_name = addslashes($_POST['name']);

    $update_category = "UPDATE categories SET categoryname = '$update_name' WHERE id = '$update_id'";
    $result_update_category = mysqli_query($conn, $update_category);

    if($result_update_category){
      echo "<script>alert('Successfully Updated');</script>";
    }else{
      echo "<script>alert('Update Unsucessful');</script>";
    }
  }

  if(isset($_POST['btndelete'])){
    $update_id = $_POST['id'];

    $delete_category = "DELETE FROM categories WHERE id = '$update_id'";
    $result_delete_category = mysqli_query($conn, $delete_category);

    if($result_delete_category){
      echo "<script>alert('Successfully Deleted');</script>";
    }else{
      echo "<script>alert('Delete Unsucessful');</script>";
    }
  }

  if(isset($_POST['btnadd'])){
    $add_name = addslashes($_POST['addname']);

    $add_category = "INSERT categories (categoryname) VALUES ('$add_name')";
    $result_add_category = mysqli_query($conn, $add_category);

    if ($result_add_category){
      echo "<script>alert('Successfully Added');</script>";
    }else{
      echo "<script>alert('Unable to add category');</script>";
    }
  }
  

?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content=" description here ">
    <title></title>
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
    <!--  Android 5 Chrome Color-->
    <meta name="theme-color" content="#009688">
    <!-- CSS-->
    <link href="../../css/prism.css" rel="stylesheet">
    <link href="../../css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="../../js/sidemenu.js"></script>
    <script src="../../ckeditor/ckeditor.js"></script>

<style>
  body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }

  nav ul li a:hover, nav ul li.active {
    background-color: #00695c;
  }
      
</style>
</head>
<body>

   <header>
      <div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only"><i class="material-icons" style="padding-top: 8px">menu</i></a></div>
      <ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="#" class="brand-logo">
            <img id="front-page-logo" src="images/logo.png"></a></li>
        <li class='bold'><a href='index.php' class='waves-effect waves-teal'>Home</a></li>
        <?php
        if(!isset($_SESSION['staffusername'])){
         echo "<script>alert('You must be logged in to enter this page!'); window.location: '../index.php';</script>";
        }else{
          echo "<li class='bold'><a href='../logout.php' class='waves-effect waves-teal'>Logout</a></li>";
        }
        ?>
    <li>&nbsp; &nbsp;Categories</li>
    <li class="no-padding">
        <ul class="collapsible collapsible-accordion">
        <?php

          $load_maincategory_query = "SELECT * FROM categories";
          $result_maincategory = mysqli_query($conn, $load_maincategory_query);
          if ($result_maincategory){
            $counter_maincategory = mysqli_num_rows($result_maincategory);
              if ($counter_maincategory>0){
                while($row = mysqli_fetch_assoc($result_maincategory)){
                $maincategory_id = $row['id'];
                $maincategory_name = $row['categoryname'];
                  echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>".$maincategory_name."</a>";
                  $load_subcategory_query = "SELECT * FROM subcategories WHERE categoryid = '$maincategory_id'";
                  $result_subcategory = mysqli_query($conn, $load_subcategory_query);
                  if ($result_subcategory){
                    $counter_subcategory = mysqli_num_rows($result_subcategory);
                    if ($counter_subcategory>0){
                      while($row2 = mysqli_fetch_assoc($result_subcategory)){
                      $subcategory_maincategoryid = $row2['categoryid'];
                      $subcategory_name = $row2['subcategoryname'];
                      $subcategory_id = $row2['id'];
                      $get_items_on_this_category = "SELECT * FROM items WHERE categoryid = $maincategory_id AND subcategoryid = $subcategory_id";
                      $result_items_on_this_category = mysqli_query($conn, $get_items_on_this_category);
                      if ($result_items_on_this_category){
                        $counter_items_on_this_category = mysqli_num_rows($result_items_on_this_category);
                        echo"                       
                          <div class='collapsible-body'>
                                <ul>
                          <li><a href='#'>".$subcategory_name." (".$counter_items_on_this_category.")</a></li>
                                </ul>
                              </div>";
                      }
                      }
                    }else{
                      echo"                       
                          <div class='collapsible-body'>
                                <ul>
                          <li><a href='#'>Failed to load</a></li>
                                </ul>
                              </div>";
                    }
                  }
                }
              }else{
                echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>Failed to load</a>";
              }
          }



        ?>
        </li>
            
      </ul>
    </li>
    </header>

  <nav>
    <div class="nav-wrapper teal">
      <a href="#" class="brand-logo"><img id="front-page-logo" src="images/logo.png"></a>
      <ul class="right hide-on-med-and-down">
      <?php
      if(isset($_SESSION['staffusername'])){
        echo"<li><a class='waves-effect waves-light' href='../logout.php'>Logout<i class='left material-icons'>send</i></a></li>";
      }else{
         echo "<script>alert('You must be logged in to enter this page!'); window.location: '../index.php';</script>";
      }

      ?>
      </ul>
    </div>
  </nav>
  
  <main>
    <div class="container">
      <div class="row">
        <div class="col s12">
        <br><br>
          <div class='center'>
          <a class="waves-effect waves-light btn">Items</a>
          <a href='shipping.php' class="waves-effect waves-light btn">Shipping</a>
          <a href='users.php' class="waves-effect waves-light btn">Users</a>
          <a class="waves-effect waves-light btn">Main Category</a>
          <a href='subcategory.php' class="waves-effect waves-light btn">Sub Category</a>
          </div>
        <br><br>
          <table class='centered responsive-table'>
            <thead>
              <tr>
                  <th data-field='btn'><a href='#add' class='modal-trigger btn-floating btn-small waves-effect waves-light teal'><i class='material-icons'>add</i></a></th>
                  <th data-field='id'>ID</th>
                  <th data-field='name'>Category Name</th>
              </tr>
            </thead>

            <tbody>
            <?php 

            $load_maincategory = "SELECT * FROM categories";
            $result_load_maincategory = mysqli_query($conn, $load_maincategory);

            if ($result_load_maincategory){
              $counter_load_maincategory = mysqli_num_rows($result_load_maincategory);
              if ($counter_load_maincategory > 0){
                while ($row8 = mysqli_fetch_assoc($result_load_maincategory)){
                  $category_id = $row8['id'];
                  $category_name = $row8['categoryname'];

                  echo "<tr>
                          <td><a href='#manage' data-id='".$category_id."' data-name='".$category_name."' class='modal-trigger btn-floating btn-small waves-effect waves-light teal'><i class='material-icons'>edit</i></a></td>
                          <td>".$category_id."</td>
                          <td>".$category_name."</td>
                        </tr>
                  ";

                }
              }
            }

            ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  
  <footer class="page-footer teal">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2016 Lozodo lol
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
    </footer>

  <!-- Login Modal Structure -->
  <div id="login_modal" class="modal modal-fixed-footer">
  
    <form method="post" class="signin" action="#" class="row s12">
        
          <div class="col" style="margin: 50px 30px 30px 30px;">
          <h4 align="center">User Login</h4><br>
            <div class="col">
            <div class="input-field col s6">
              <input id="last_name" type="text" class="validate" name="login_username">
              <label for="last_name">Username</label>
            </div>
            <div class="input-field col s6">
              <input id="last_name" type="password" class="validate" name="login_password">
              <label for="last_name">Password</label>
            </div>
          <br><br>
          <center>
           <button class="btn waves-effect waves-light" name="loginbtn" type="submit">Login
            <i class="material-icons right">send</i>
            </button>
           <a class="waves-effect waves-light btn modal-trigger" href="#registermodal"><i class="material-icons right">cloud</i>Register</a></center>
          </div>
          </div>
          </form>
  </div>

  <div id="manage" class="modal">
    <form method='post' action='#' class="modal-content getvalue">
      <h4>Edit</h4>
      <div class='row'>
        <div class='col s12'>
        <input type='hidden' id='id' name='id'>
          <div class='input-field inline'>
            <input id='name' name='name' type='text' class='validate'>
            <label for='name'>Category Name</label>
          </div>
        </div>
        <div class='col s12 center'>
        <button type='submit' name='btnupdate' class='waves-effect waves-light btn'>Update</button>
        <button type='submit' name='btndelete' class='waves-effect waves-light btn'>Delete</button>
        </div>
      </div>
    </form>
  </div>

  <div id="add" class="modal">
    <form method='post' action='#' class="modal-content">
      <h4>Add</h4>
      <div class='row'>
        <div class='col s12'>
          <div class='input-field inline'>
            <input id='name' name='addname' type='text' class='validate'>
            <label for='name'>Category Name</label>
          </div>
        </div>
        <div class='col s12 center'>
        <button type='submit' name='btnadd' class='waves-effect waves-light btn'>Add Category</button>
        </div>
      </div>
    </form>
  </div>
  
  <!--  Scripts-->
    <script src="../../js/jquery-2.1.4.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="../../bin/jquery-2.1.1.min.js"><\/script>'); }
    </script>
    <script src="../../js/jquery.timeago.min.js"></script>
    <script src="../../js/prism.js"></script>
    <script src="../../jade/lunr.min.js"></script>
    <script src="../../jade/search.js"></script>
    <script src="../../bin/materialize.js"></script>
    <script src="../../js/init.js"></script> 
    <script type='text/javascript'>
    $(document).on('click', '.modal-trigger', function () {
       var id = $(this).data('id');
       $('.getvalue #id').val( id );
       var name = $(this).data('name');
       $('.getvalue #name').val( name );
       Materialize.updateTextFields();
       $('#manage_modal').modal('show');
    });
    </script>
  
</body>
</html>