<?php

session_start();
unset($_SESSION['staffusername']);
header('Location: index.php');

?>