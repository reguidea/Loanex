<?php

require_once('../dbconn.php');
session_start();

if(isset($_POST['btnsubmit'])){
  $username = addslashes($_POST['username']);
  $password = addslashes(md5($_POST['password']));

  $login = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
  $result_login = mysqli_query($conn, $login);
  if($result_login){
    $counter_login = mysqli_num_rows($result_login);
    if ($counter_login > 0){
      while($row = mysqli_fetch_assoc($result_login)){
        $position = $row['position'];
        //echo $position;
      }
      $_SESSION['staffusername'] = $username;
      if ($position == 2){
      header("Location: admin/index.php");
      }else if($position == 1){
      header("Location: mod/index.php");
      }else{
        echo "<script>alert('You must be a staff to continue!');</script>";
      }
    }else{
      echo "<script>alert('Username or password is incorrect!');</script>";
    }
  }
}

?>

<html>
    <head>
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="../dist/css/materialize.min.css"  media="screen,projection"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>
    <style>
    	html, body{
    		background-color: rgb(0, 150, 136);
    		margin: 0;
    		padding: 0;
    	}
    </style>

    <body>
      <script type="text/javascript" src="../js/jquery-2.1.4.min.js"></script>
      <script type="text/javascript" src="../dist/js/materialize.min.js"></script>

      <div class="col s12 m5" style="margin: 10% 10%;">
        <div class="card-panel white">
          <h5 class="center-align"><i class="material-icons">lock</i>&nbsp; Staff Login</h5>
          <div class="row">
		    <form class="col s12" method="post" action="#">
		      <div class="row">
		        <div class="input-field col s12">
		          <input type="text" id='username' class="validate" name="username">
		          <label for="username">Username</label>
		        </div>
		        <div class="input-field col s12">
		          <input type="password" id='password' class="validate" name="password">
		          <label for="password">Password</label>
		        </div>
		        <div align="center" class="input-field col s12">
				<button class="btn waves-effect waves-light" type="submit" name="btnsubmit">Login
				    <i class="material-icons right">send</i>
				</button>
		        </div>
		        
		      </div>
		    </form>
	  </div>
        </div>
        </div>

    </body>
  </html>