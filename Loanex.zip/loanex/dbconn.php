<?php

	$conn = mysqli_connect('localhost', 'root', '');
	if (!$conn){
		die('Failed to connect to server' . mysqli_error($conn));
	}else{
		$select_db = mysqli_select_db($conn, 'lazada');
		if (!$select_db){
			die('Failed to connect to database: ' . mysqli_error($conn));
		}
	}
	

?>