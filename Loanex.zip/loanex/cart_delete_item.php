<?php

session_start();
include('dbconn.php');

	$id = $_REQUEST['id'];
	if(isset($id)){
		$delete_item = "DELETE FROM cart WHERE id = '$id'";
		$result_delete_item = mysqli_query($conn, $delete_item);

		if ($result_delete_item){
			header('Location: ' . $_SERVER['HTTP_REFERER']);
		}else{
			echo "
				  <script type='text/javascript'>
				  alert('Delete Unsuccessful, Unexpected Error')
				  window.location = 'cart.php';
				  </script>";
		}
	}

?>