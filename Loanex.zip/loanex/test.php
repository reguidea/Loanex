<?php

$now = date("Y-m-d");
$end = date("2016-12-04");

if ($now > $end){
	echo "A";
}else{
	echo "B";
}

if (isset($_COOKIE['lazada_couponcode'])){
	echo "C";
}else{
	echo "D";
}

?>