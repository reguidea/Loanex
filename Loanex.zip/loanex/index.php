<?php

	include('dbconn.php');
  session_start();

  if(isset($_POST['loginbtn'])){
    $username = addslashes($_POST['login_username']);
    $password = addslashes(md5($_POST['login_password']));

    $login = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result_login = mysqli_query($conn, $login);
    if($result_login){
      $counter_login = mysqli_num_rows($result_login);
      if ($counter_login>0){
        $_SESSION['username'] = $username;
      }else{
        echo "<script>alert('Username and Password is incorrect');</script>";
      }
    }
  }

  if(isset($_POST['registersubmit'])){
  
    $reg_username = addslashes($_POST['reg_username']);
    $reg_fname = addslashes($_POST['reg_fname']);
    $reg_lname = addslashes($_POST['reg_lname']);
    $reg_password = addslashes(md5($_POST['reg_password']));
    $reg_repassword = addslashes(md5($_POST['reg_repassword']));
    $reg_gender = addslashes($_POST['reg_gender']);
    $reg_email = addslashes($_POST['reg_email']);
    $reg_address = addslashes($_POST['reg_address']);
    $reg_mobile = addslashes($_POST['reg_mobile']);
    $reg_zip = addslashes($_POST['reg_zip']);
    $username_unique_checker_query = mysqli_query($conn ,"SELECT * FROM users WHERE username = '$reg_username'");
    $username_unique_checker = mysqli_num_rows($username_unique_checker_query);
    $email_unique_checker_query = mysqli_query($conn ,"SELECT * FROM users WHERE email = '$reg_email'");
    $email_unique_checker = mysqli_num_rows($email_unique_checker_query);
    
    if ((empty($reg_zip))){
      echo"
          <script type='text/javascript'>
          alert('Zip must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if ((empty($reg_address))){
      echo"
          <script type='text/javascript'>
          alert('Address must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if ((empty($reg_username))){
      echo"
          <script type='text/javascript'>
          alert('Username must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if ((empty($reg_fname))){
      echo"
          <script type='text/javascript'>
          alert('First Name must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_lname))){
      echo"
          <script type='text/javascript'>
          alert('Last Name must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_password))){
      echo"
          <script type='text/javascript'>
          alert('Password must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_repassword))){
      echo"
          <script type='text/javascript'>
          alert('Re-password must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if((empty($reg_email))){
      echo"
          <script type='text/javascript'>
          alert('Email must have a value!')
          window.location = 'index.php' 
          </script>";
    }else if($reg_password != $reg_repassword){
        echo"
          <script type='text/javascript'>
          alert('Password not match!')
          window.location = 'index.php' 
          </script>";
      }else if (!filter_var($reg_email, FILTER_VALIDATE_EMAIL)){
        echo"
          <script type='text/javascript'>
          alert('Invalid Email Format')
          window.location = 'index.php' 
          </script>";
      }else if($username_unique_checker != 0){
        echo"
          <script type='text/javascript'>
          alert('Username already exist!')
          window.location = 'index.php' 
          </script>";
      }else if($email_unique_checker != 0){
        echo"
          <script type='text/javascript'>
          alert('Email already exist!')
          window.location = 'index.php' 
          </script>";
      }else{
        $reg_query = "INSERT INTO users (fname, lname, email, gender, username, password, default_address, mobile, zip) VALUES ('$reg_fname', '$reg_lname', '$reg_email', '$reg_gender', '$reg_username', '$reg_password', '$reg_address', '$reg_mobile', '$reg_zip')";
        $check = mysqli_query($conn ,$reg_query);
        if (!$check){
          echo "
          <script type='text/javascript'>
          alert('Register failed!')
          </script>";
        }else{
          echo"
            <script type='text/javascript'>
            window.location = 'index.php' 
            alert('Successfully registed!')
            
            </script>
            ";
          
        }
      }
    }

  if(isset($_POST['searchbtn'])){
    $search = addslashes($_POST['search']);
    header("Location: index.php?s=$search");
  }


?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content=" Description here ">
    <title></title>
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
    <!--  Android 5 Chrome Color-->
    <meta name="theme-color" content="#009688">
    <!-- CSS-->
    <link href="css/prism.css" rel="stylesheet">
    <link href="css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   	<script src="js/sidemenu.js"></script>

<style>
  body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }

  nav ul li a:hover, nav ul li.active {
    background-color: #00695c;
  }
      
</style>
</head>
<body>

   <header>
      <div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only"><i class="material-icons" style="padding-top: 8px">menu</i></a></div>
      <ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="#" class="brand-logo">
            <img id="front-page-logo" src="images/logo.png"></a></li>
        <li class='bold'><a href='index.php' class='waves-effect waves-teal'>Home</a></li>
        <?php
          if(!isset($_SESSION['username'])){
            echo "<li class='bold'><a href='#login_modal' class='modal-trigger waves-effect waves-teal'>Login</a></li>";
          }else{
            echo "<li class='bold'><a class='waves-effect waves-light' href='profile.php'>My Profile</a></li>";
            echo "<li class='bold'><a class='waves-effect waves-light' href='orders.php'>My Orders</a></li>";
            $get_cart = "SELECT * FROM cart WHERE username = '$_SESSION[username]'";
            $result_get_cart = mysqli_query($conn, $get_cart);
            if ($result_get_cart){
              $counter_get_cart = mysqli_num_rows($result_get_cart);
                if ($counter_get_cart>0){
                  echo "<li class='bold'><a href='cart.php' class='waves-effect waves-teal'>Cart [ ".$counter_get_cart." ]</a></li>";
                }else{
                  echo "<li class='bold'><a class='waves-effect waves-light' href='cart.php'>Cart</a></li>";
                }
              }
            
            echo "<li class='bold'><a href='logout.php' class='waves-effect waves-teal'>Logout</a></li>";
          }
        ?>
    <li>&nbsp; &nbsp;Categories</li>
		<li class="no-padding">
        <ul class="collapsible collapsible-accordion">
        <?php

        	$load_maincategory_query = "SELECT * FROM categories";
        	$result_maincategory = mysqli_query($conn, $load_maincategory_query);
        	if ($result_maincategory){
        		$counter_maincategory = mysqli_num_rows($result_maincategory);
        			if ($counter_maincategory>0){
        				while($row = mysqli_fetch_assoc($result_maincategory)){
        				$maincategory_id = $row['id'];
        				$maincategory_name = $row['categoryname'];
        					echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>".$maincategory_name."</a>";
        					$load_subcategory_query = "SELECT * FROM subcategories WHERE categoryid = '$maincategory_id'";
        					$result_subcategory = mysqli_query($conn, $load_subcategory_query);
        					if ($result_subcategory){
        						$counter_subcategory = mysqli_num_rows($result_subcategory);
        						if ($counter_subcategory>0){
		        					while($row2 = mysqli_fetch_assoc($result_subcategory)){
		        					$subcategory_maincategoryid = $row2['categoryid'];
		        					$subcategory_name = $row2['subcategoryname'];
                      $subcategory_id = $row2['id'];
                      $get_items_on_this_category = "SELECT * FROM items WHERE categoryid = $maincategory_id AND subcategoryid = $subcategory_id";
                      $result_items_on_this_category = mysqli_query($conn, $get_items_on_this_category);
                      if ($result_items_on_this_category){
                        $counter_items_on_this_category = mysqli_num_rows($result_items_on_this_category);
		        						echo"        	              
		        							<div class='collapsible-body'>
								                <ul>
													<li><a href='items.php?ctgid=".$maincategory_id."&sctgid=".$subcategory_id."'>".$subcategory_name." (".$counter_items_on_this_category.")</a></li>
								                </ul>
							                </div>";
                      }
		        					}
        						}else{
        							echo"        	              
		        							<div class='collapsible-body'>
								                <ul>
													<li><a href='#'>Failed to load</a></li>
								                </ul>
							                </div>";
        						}
        					}
        				}
        			}else{
        				echo "<li class='bold'><a class='collapsible-header waves-effect waves-teal'>Failed to load</a>";
        			}
        	}



        ?>
        </li>
            
      </ul>
	  </li>
    </header>

  <nav>
    <div class="nav-wrapper teal">
      <a href="#" class="brand-logo"><img id="front-page-logo" src="images/logo.png"></a>
      <ul class="right hide-on-med-and-down">
      <?php
      if(isset($_SESSION['username'])){
        $get_cart = "SELECT * FROM cart WHERE username = '$_SESSION[username]'";
        $result_get_cart = mysqli_query($conn, $get_cart);
        if ($result_get_cart){
          $counter_get_cart = mysqli_num_rows($result_get_cart);
            if ($counter_get_cart>0){
              echo "<li><a class='waves-effect waves-light' href='cart.php'>Cart<i class='left material-icons'>shopping_cart</i><span class='badge white-text'>[ ".$counter_get_cart." ]</span></a></li>";
            }else{
              echo "<li><a class='waves-effect waves-light' href='cart.php'>Cart<i class='left material-icons'>shopping_cart</i></a></li>";
            }
          }
        echo"<li><a class='waves-effect waves-light' href='logout.php'>Logout<i class='left material-icons'>send</i></a></li>";
      }else{
        echo"<li><a class='modal-trigger waves-effect waves-light' href='#login_modal'>Login<i class='left material-icons'>send</i></a></li>";
      }

      ?>
      </ul>
    </div>
  </nav>
  
  <main>
  <div class="section">
    <div class="row">
	     <div class="container">
          <div class='row'>
              <form class="row" method='post' action='#'>
                <div class="input-field col s10">
                  <input id='search' name='search' type="text" class="validate">
                  <label for="search"><i class="material-icons">search</i></label>
                </div>
                <div class="input-field col s1">
                  <button type='submit' name='searchbtn' class="waves-effect waves-light btn">Search</button>
                </div>
              </form>
          </div>
			    <div class="row">
            <?php

              if(isset($_REQUEST['s'])){
                $search_query = $_REQUEST['s'];
                $load_items_query = "SELECT * FROM items WHERE name LIKE '%$search_query%' ORDER BY id LIMIT 12";
              }else{
                $load_items_query = "SELECT * FROM items ORDER BY id DESC LIMIT 12";
              }
              $result_load_items = mysqli_query($conn, $load_items_query);
              if ($result_load_items){
                $counter_load_items = mysqli_num_rows($result_load_items);
                if ($counter_load_items>0){
                  while($row3 = mysqli_fetch_assoc($result_load_items)){
                    $item_name = $row3['name'];
                    $item_price = $row3['price'];
                    $item_img_link = $row3['imglink'];
                    $item_category_id = $row3['categoryid'];
                    $item_subcategory_id = $row3['subcategoryid'];
                    $item_id = $row3['id'];
                    $item_discount = $row3['discount'];
                    if ($item_discount>0){
                      $discount_value = $item_discount/100;
                      $real_price_temp = $item_price;
                      $discounted_price = $item_price - ($item_price * $discount_value);
                      $item_price = round($discounted_price, 2);
                      $discounted_price = $real_price_temp;
                    }
                    echo"
                      <a href='showitem.php?id=".$item_id."' class='col s6 m4 l4 waves-effect waves-teal waves-light'>
                        <div class='card hoverable'>
                          <div class='card-image'>
                            <img height='30%' src=".$item_img_link.">
                          </div>
                          <div class='card-content'>
                            <p class='grey-text truncate'>".$item_name."</p>
                            <p class='red-text'>₱ ".number_format((round($item_price, 2)), 2, '.', ',')."</p>"; 
                              if($item_discount>0){
                                echo "<small class='black-text' style='text-decoration: line-through;'>₱ ".number_format((round($discounted_price, 2)), 2, '.', ',')."</small>"; 
                              }else{
                                echo "<small class='black-text'>&nbsp;</small>";
                              }
                            if($item_discount>0){
                              echo "<small class='black-text'>  -".$item_discount."%</small>";
                            }else{
                              echo "<small class='black-text'><br></small>";
                            }
                          echo"
                          </div>
                        </div>
                      </a>";
                  }
                  }else{
                    echo "
                      <div class='card'>
                        <div class='card-content'>
                          <h5>No results found</h5>
                        </div>
                      </div>
                    ";
                  }
                }

            ?>
          </div>
				</div>
	   </div>
	</div>
  </main>
  
  <footer class="page-footer teal">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2016 Lozodo lol
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
    </footer>

  <!-- Login Modal Structure -->
  <div id="login_modal" class="modal modal-fixed-footer">
  
    <form method="post" class="signin" action="#" class="row s12">
        
          <div class="col" style="margin: 50px 30px 30px 30px;">
          <h4 align="center">User Login</h4><br>
            <div class="col">
            <div class="input-field col s6">
              <input id="last_name" type="text" class="validate" name="login_username">
              <label for="last_name">Username</label>
            </div>
            <div class="input-field col s6">
              <input id="last_name" type="password" class="validate" name="login_password">
              <label for="last_name">Password</label>
            </div>
          <br><br>
          <center>
           <button class="btn waves-effect waves-light" name="loginbtn" type="submit">Login
            <i class="material-icons right">send</i>
            </button>
           <a class="waves-effect waves-light btn modal-trigger" href="#registermodal"><i class="material-icons right">cloud</i>Register</a></center>
          </div>
          </div>
          </form>
  </div>

    <div id="registermodal" class="modal modal-fixed-footer">
    <form method="post" class="signin" action="#" class="row s12">
        
          <div class="col" style="margin: 30px 30px 30px 30px;">
            <div class="col">
            <div class="input-field col s6">
              <input id="username" type="text" class="validate" name="reg_username" autocomplete="off"required>
              <label for="username">Username</label>
            </div>
            <div class="input-field col s6">
              <input id="password" type="password" class="validate" name="reg_password" autocomplete="off" required>
              <label for="password">Password</label>
            </div>
            <div class="input-field col s6">
              <input id="re-password" type="password" class="validate" name="reg_repassword" autocomplete="off" required>
              <label for="re-password">Re-Password</label>
            </div>
            <div class="input-field col s6">
              <input id="first_name" type="text" class="validate" name="reg_fname" autocomplete="off" required>
              <label for="first_name">First Name</label>
            </div>
            <div class="input-field col s6">
              <input id="last_name" type="text" class="validate" name="reg_lname" autocomplete="off" required>
              <label for="last_name">Last Name</label>
            </div>
            <div class="input-field col s6">
              <input id="email" type="email" class="validate" name="reg_email" autocomplete="off" required>
              <label for="email">E-mail</label>
            </div>
              <div class="col s12">
                <div class="row">
                  <div class="input-field col s12">
                    <textarea id="address" name='reg_address' class="materialize-textarea" required></textarea>
                    <label for="address">Address</label>
                  </div>
                </div>
              </div>
            <div class="input-field col s6">
              <input id="mobile" type="number" class="validate" name="reg_mobile" autocomplete="off">
              <label for="mobile">Mobile</label>
            </div>
            <div class="input-field col s6">
              <input id="zip" type="number" class="validate" name="reg_zip" autocomplete="off" required>
              <label for="zip">Zip</label>
            </div>
            <div class="input-field col s12">
              <select name="reg_gender" required>
                <option value="" disabled selected>Choose an option</option>
                <option value="1">Male</option>
                <option value="0">Female</option>
              </select>
              <label>Gender</label>
            </div>
            
          <center>
           <button class="btn waves-effect waves-light" type="submit" name="registersubmit">Register
            <i class="material-icons right">send</i>
            </button>
          </center>
          </div>
          </div>
          </form>
      </div>
	
	<!--  Scripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.js"><\/script>'); }
    </script>
    <script src="js/jquery.timeago.min.js"></script>
    <script src="js/prism.js"></script>
    <script src="jade/lunr.min.js"></script>
    <script src="jade/search.js"></script>
    <script src="bin/materialize.js"></script>
    <script src="js/init.js"></script>	

	
</body>
</html>